/* =========================================================
   RECICLA +
   SCRIPT.JS
   ========================================================= */

const prefersReducedMotion =
    window.matchMedia(
        "(prefers-reduced-motion: reduce)"
    ).matches;

const hasFinePointer =
    window.matchMedia(
        "(hover: hover) and (pointer: fine)"
    ).matches;


/* =========================================================
   PRELOADER + ENTRADA DEL HERO
   ========================================================= */

(function initPreloader() {

    const preloader =
        document.querySelector("#preloader");

    const fill =
        document.querySelector("#preloader-fill");

    const number =
        document.querySelector("#preloader-number");

    if (!preloader) {

        return;

    }


    document.body.classList.add("is-loading");


    /* Si el usuario prefiere menos movimiento,
       saltamos directo a mostrar el contenido. */

    if (prefersReducedMotion) {

        preloader.remove();

        document.body.classList.remove("is-loading");

        revealHero();

        return;

    }


    let progress = 0;

    const duration = 1400;

    const startTime = performance.now();


    function tick(now) {

        const elapsed =
            now - startTime;

        /* Avanzamos más rápido al inicio y
           frenamos cerca del final, y sólo
           llegamos al 100% cuando la página
           ya cargó de verdad. */

        const rawProgress =
            Math.min(elapsed / duration, 1);

        const eased =
            1 - Math.pow(1 - rawProgress, 3);

        progress =
            Math.round(eased * 100);

        if (fill) {

            fill.style.width =
                progress + "%";

        }

        if (number) {

            number.textContent =
                progress;

        }


        if (rawProgress < 1) {

            requestAnimationFrame(tick);

        } else {

            finishLoading();

        }

    }


    function finishLoading() {

        preloader.style.transition =
            "opacity 0.6s ease, visibility 0.6s ease";

        preloader.style.opacity = "0";

        preloader.style.visibility = "hidden";


        document.body.classList.remove(
            "is-loading"
        );


        setTimeout(
            () => {

                preloader.remove();

            },
            650
        );


        revealHero();

    }


    requestAnimationFrame(tick);

})();


function revealHero() {

    /* PALABRAS DEL TITULO */

    const lines =
        document.querySelectorAll(
            ".hero-title .line-inner"
        );

    lines.forEach(
        (line) => {

            line.classList.add("in");

        }
    );


    const underline =
        document.querySelector(
            ".hero-title strong.line"
        );

    if (underline) {

        underline.classList.add(
            "underline-in"
        );

    }


    /* RESTO DEL HERO, EN CASCADA */

    const heroReveals =
        document.querySelectorAll(
            ".hero-reveal"
        );

    heroReveals.forEach(
        (element, index) => {

            element.style.transitionDelay =
                (0.35 + index * 0.12) + "s";

            requestAnimationFrame(
                () => {

                    element.classList.add("is-in");

                }
            );

        }
    );

}


/* =========================================================
   CURSOR PERSONALIZADO
   ========================================================= */

if (hasFinePointer && !prefersReducedMotion) {

    const cursorDot =
        document.querySelector("#cursor-dot");

    const cursorRing =
        document.querySelector("#cursor-ring");


    if (cursorDot && cursorRing) {

        let mouseX = window.innerWidth / 2;
        let mouseY = window.innerHeight / 2;

        let ringX = mouseX;
        let ringY = mouseY;


        window.addEventListener(
            "mousemove",
            (event) => {

                mouseX = event.clientX;
                mouseY = event.clientY;

                cursorDot.style.transform =
                    `translate(${mouseX}px, ${mouseY}px) translate(-50%, -50%)`;

            }
        );


        function animateRing() {

            /* Interpolación suave para que el
               aro vaya "a la zaga" del puntero. */

            ringX +=
                (mouseX - ringX) * 0.16;

            ringY +=
                (mouseY - ringY) * 0.16;

            cursorRing.style.transform =
                `translate(${ringX}px, ${ringY}px) translate(-50%, -50%)`;

            requestAnimationFrame(animateRing);

        }

        requestAnimationFrame(animateRing);


        const hoverTargets =
            document.querySelectorAll(
                "a, button, .team-member, .step-card, .category"
            );

        hoverTargets.forEach(
            (target) => {

                target.addEventListener(
                    "mouseenter",
                    () => {

                        cursorRing.classList.add(
                            "is-active"
                        );

                    }
                );

                target.addEventListener(
                    "mouseleave",
                    () => {

                        cursorRing.classList.remove(
                            "is-active"
                        );

                    }
                );

            }
        );


        /* CHISPAS QUE SIGUEN AL CURSOR */

        let lastSparkTime = 0;

        window.addEventListener(
            "mousemove",
            (event) => {

                const now = performance.now();

                if (now - lastSparkTime < 70) {

                    return;

                }

                lastSparkTime = now;


                const spark =
                    document.createElement("span");

                spark.className = "cursor-spark";

                spark.style.left = event.clientX + "px";
                spark.style.top = event.clientY + "px";

                document.body.appendChild(spark);

                setTimeout(
                    () => {

                        spark.remove();

                    },
                    620
                );

            }
        );

    }

}


/* =========================================================
   BOTONES MAGNETICOS
   ========================================================= */

if (hasFinePointer && !prefersReducedMotion) {

    const magneticButtons =
        document.querySelectorAll(".magnetic");

    magneticButtons.forEach(
        (button) => {

            button.style.transition =
                "transform 0.25s cubic-bezier(.2, .8, .2, 1)";

            button.addEventListener(
                "mousemove",
                (event) => {

                    const rect =
                        button.getBoundingClientRect();

                    const relX =
                        event.clientX - rect.left - rect.width / 2;

                    const relY =
                        event.clientY - rect.top - rect.height / 2;

                    button.style.transform =
                        `translate(${relX * 0.25}px, ${relY * 0.35}px)`;

                }
            );

            button.addEventListener(
                "mouseleave",
                () => {

                    button.style.transform =
                        "translate(0, 0)";

                }
            );

        }
    );

}


/* =========================================================
   RIPPLE AL HACER CLICK EN BOTONES
   ========================================================= */

if (!prefersReducedMotion) {

    const rippleButtons =
        document.querySelectorAll(".magnetic");

    rippleButtons.forEach(
        (button) => {

            button.addEventListener(
                "click",
                (event) => {

                    const rect =
                        button.getBoundingClientRect();

                    const size =
                        Math.max(rect.width, rect.height) * 2;

                    const ripple =
                        document.createElement("span");

                    ripple.className = "ripple";

                    ripple.style.width =
                        ripple.style.height =
                            size + "px";

                    ripple.style.left =
                        (event.clientX - rect.left - size / 2) + "px";

                    ripple.style.top =
                        (event.clientY - rect.top - size / 2) + "px";

                    button.appendChild(ripple);

                    setTimeout(
                        () => {

                            ripple.remove();

                        },
                        620
                    );

                }
            );

        }
    );

}


/* =========================================================
   CONTADORES DE IMPACTO
   ========================================================= */

(function initImpactCounters() {

    const counters =
        document.querySelectorAll(
            ".impact-number"
        );

    if (!counters.length) {

        return;

    }


    const counterObserver =
        new IntersectionObserver(

            (entries) => {

                entries.forEach(
                    (entry) => {

                        if (
                            entry.isIntersecting
                        ) {

                            animateCounter(
                                entry.target
                            );

                            counterObserver.unobserve(
                                entry.target
                            );

                        }

                    }
                );

            },

            {
                threshold: 0.5
            }

        );


    counters.forEach(
        (counter) => {

            counterObserver.observe(counter);

        }
    );


    function animateCounter(element) {

        const target =
            parseInt(
                element.dataset.count,
                10
            ) || 0;

        if (prefersReducedMotion) {

            element.textContent = target;

            return;

        }


        const duration = 1300;

        const startTime = performance.now();


        function step(now) {

            const rawProgress =
                Math.min(
                    (now - startTime) / duration,
                    1
                );

            const eased =
                1 - Math.pow(1 - rawProgress, 3);

            element.textContent =
                Math.round(eased * target);


            if (rawProgress < 1) {

                requestAnimationFrame(step);

            } else {

                element.classList.add(
                    "count-done"
                );

            }

        }

        requestAnimationFrame(step);

    }

})();


/* =========================================================
   MINI JUEGO — PONLO A PRUEBA
   ========================================================= */

(function initSortingGame() {

    const itemEl =
        document.querySelector("#game-item");

    const questionEl =
        document.querySelector("#game-question");

    const optionButtons =
        document.querySelectorAll(".game-option");

    const feedbackEl =
        document.querySelector("#game-feedback");

    const correctCountEl =
        document.querySelector("#game-correct");

    const streakCountEl =
        document.querySelector("#game-streak");

    const gameCard =
        document.querySelector(".game-card");

    if (!itemEl || !optionButtons.length || !gameCard) {

        return;

    }


    const items = [
        { emoji: "🍌", cat: "organico" },
        { emoji: "🧴", cat: "plastico" },
        { emoji: "📦", cat: "papel" },
        { emoji: "🍾", cat: "vidrio" },
        { emoji: "🍎", cat: "organico" },
        { emoji: "🥤", cat: "plastico" },
        { emoji: "📰", cat: "papel" },
        { emoji: "🫙", cat: "vidrio" },
        { emoji: "🥕", cat: "organico" },
        { emoji: "🛍️", cat: "plastico" },
        { emoji: "📄", cat: "papel" },
        { emoji: "🧪", cat: "vidrio" }
    ];

    const correctMessages = [
        "¡Exacto!",
        "¡Así se hace!",
        "¡Ojo entrenado!",
        "¡Perfecto!",
        "¡Eso es!"
    ];

    const wrongMessages = {
        plastico: "Casi, ese iba en Plástico.",
        papel: "Casi, ese iba en Papel y cartón.",
        organico: "Casi, ese iba en Orgánico.",
        vidrio: "Casi, ese iba en Vidrio."
    };


    let correctCount = 0;
    let streak = 0;
    let currentItem = null;
    let locked = false;


    function pickItem() {

        let next = currentItem;

        while (next === currentItem) {

            next =
                items[
                    Math.floor(Math.random() * items.length)
                ];

        }

        return next;

    }


    function showItem() {

        currentItem = pickItem();

        itemEl.textContent = currentItem.emoji;

        /* Reiniciamos la animación de entrada */

        itemEl.style.animation = "none";

        void itemEl.offsetWidth;

        itemEl.style.animation = "";


        questionEl.textContent =
            "¿Dónde va este residuo?";

        feedbackEl.textContent = "";

        feedbackEl.classList.remove("is-wrong");


        optionButtons.forEach(
            (button) => {

                button.classList.remove(
                    "is-correct",
                    "is-wrong"
                );

                button.disabled = false;

            }
        );


        locked = false;

    }


    function spawnConfetti(originButton) {

        if (prefersReducedMotion) {

            return;

        }

        const colors =
            ["#20c96b", "#a9f46c", "#0b7d43", "#ffffff"];

        const rect =
            originButton.getBoundingClientRect();

        const cardRect =
            gameCard.getBoundingClientRect();

        const originX =
            rect.left - cardRect.left + rect.width / 2;

        const originY =
            rect.top - cardRect.top + rect.height / 2;


        for (let i = 0; i < 14; i++) {

            const particle =
                document.createElement("span");

            particle.className = "confetti-particle";


            const angle = Math.random() * Math.PI * 2;
            const distance = 40 + Math.random() * 55;

            particle.style.left = originX + "px";
            particle.style.top = originY + "px";

            particle.style.setProperty(
                "--x",
                Math.cos(angle) * distance + "px"
            );

            particle.style.setProperty(
                "--y",
                Math.sin(angle) * distance + "px"
            );

            particle.style.setProperty(
                "--r",
                Math.random() * 360 + "deg"
            );

            particle.style.background =
                colors[
                    Math.floor(Math.random() * colors.length)
                ];

            gameCard.appendChild(particle);

            setTimeout(
                () => {

                    particle.remove();

                },
                850
            );

        }

    }


    optionButtons.forEach(
        (button) => {

            button.addEventListener(
                "click",
                () => {

                    if (locked) {

                        return;

                    }

                    locked = true;


                    const chosen = button.dataset.cat;

                    const isCorrect =
                        chosen === currentItem.cat;


                    optionButtons.forEach(
                        (b) => {

                            b.disabled = true;

                        }
                    );


                    if (isCorrect) {

                        button.classList.add("is-correct");

                        correctCount++;
                        streak++;

                        correctCountEl.textContent = correctCount;
                        streakCountEl.textContent = streak;

                        feedbackEl.textContent =
                            correctMessages[
                                Math.floor(
                                    Math.random() * correctMessages.length
                                )
                            ];

                        feedbackEl.classList.remove("is-wrong");

                        spawnConfetti(button);

                    } else {

                        button.classList.add("is-wrong");

                        streak = 0;

                        streakCountEl.textContent = streak;

                        feedbackEl.textContent =
                            wrongMessages[currentItem.cat];

                        feedbackEl.classList.add("is-wrong");


                        optionButtons.forEach(
                            (b) => {

                                if (
                                    b.dataset.cat === currentItem.cat
                                ) {

                                    b.classList.add("is-correct");

                                }

                            }
                        );

                    }


                    setTimeout(
                        showItem,
                        1100
                    );

                }
            );

        }
    );


    showItem();

})();


/* =========================================================
   SCROLL PROGRESS
   ========================================================= */

const progressBar =
    document.querySelector(".scroll-progress");


function updateScrollProgress() {

    const scrollTop =
        window.scrollY;

    const pageHeight =
        document.documentElement.scrollHeight -
        window.innerHeight;

    const progress =
        (scrollTop / pageHeight) * 100;

    progressBar.style.width =
        progress + "%";
}


window.addEventListener(
    "scroll",
    updateScrollProgress
);


/* =========================================================
   ELEMENTOS QUE APARECEN AL HACER SCROLL
   ========================================================= */

const revealElements =
    document.querySelectorAll(".reveal");


const revealObserver =
    new IntersectionObserver(

        (entries) => {

            entries.forEach(
                (entry) => {

                    if (
                        entry.isIntersecting
                    ) {

                        entry.target.classList.add(
                            "visible"
                        );

                        revealObserver.unobserve(
                            entry.target
                        );

                    }

                }
            );

        },

        {
            threshold: 0.12
        }

    );


revealElements.forEach(
    (element) => {

        revealObserver.observe(
            element
        );

    }
);


/* =========================================================
   PARALLAX DEL TELEFONO PRINCIPAL
   ========================================================= */

const heroPhone =
    document.querySelector(
        ".hero-phone-area"
    );


window.addEventListener(
    "scroll",
    () => {

        if (
            window.innerWidth > 1000 &&
            heroPhone
        ) {

            const scroll =
                window.scrollY;

            heroPhone.style.marginTop =
                `${scroll * 0.04}px`;

        }

    }
);


/* =========================================================
   MOVIMIENTO DEL TELEFONO CON EL MOUSE
   ========================================================= */

document.addEventListener(
    "mousemove",
    (event) => {

        if (
            window.innerWidth < 900
        ) {

            return;

        }


        const phone =
            document.querySelector(
                ".phone"
            );


        if (!phone) {

            return;

        }


        const x =
            event.clientX /
            window.innerWidth -
            0.5;


        const y =
            event.clientY /
            window.innerHeight -
            0.5;


        phone.style.transform =
            `
            rotate(${4 + x * 5}deg)
            translate(
                ${x * 10}px,
                ${y * 10}px
            )
            `;

    }
);


/* =========================================================
   EQUIPO
   CAMBIO DE FOTOS
   ========================================================= */

const teamMembers =
    document.querySelectorAll(
        ".team-member"
    );


const teamImage =
    document.querySelector(
        "#team-photo-img"
    );


const teamRole =
    document.querySelector(
        "#team-photo-role"
    );


teamMembers.forEach(
    (member) => {

        member.addEventListener(
            "mouseenter",
            () => {


                /* QUITAR ACTIVE DE TODOS */

                teamMembers.forEach(
                    (item) => {

                        item.classList.remove(
                            "active"
                        );

                    }
                );


                /* ACTIVAR ACTUAL */

                member.classList.add(
                    "active"
                );


                /* OBTENER DATOS */

                const image =
                    member.dataset.image;


                const role =
                    member.dataset.role;


                /* CAMBIAR OPACIDAD */

                teamImage.style.opacity =
                    "0";


                /*
                 * Cambiamos la imagen después
                 * de una pequeña transición.
                 */

                setTimeout(
                    () => {

                        teamImage.src =
                            image;


                        teamImage.onload =
                            () => {

                                teamImage.style.opacity =
                                    "1";

                            };

                    },
                    180
                );


                /* CAMBIAR CARGO */

                teamRole.textContent =
                    role;

            }
        );

    }
);


/* =========================================================
   TARJETAS CON MOVIMIENTO
   ========================================================= */

const cards =
    document.querySelectorAll(
        ".step-card, .category"
    );


cards.forEach(
    (card) => {


        /* MOUSE MOVE */

        card.addEventListener(
            "mousemove",
            (event) => {

                if (
                    window.innerWidth < 900
                ) {

                    return;

                }


                const rect =
                    card.getBoundingClientRect();


                const x =
                    event.clientX -
                    rect.left;


                const y =
                    event.clientY -
                    rect.top;


                const centerX =
                    rect.width / 2;


                const centerY =
                    rect.height / 2;


                const rotateX =
                    (
                        (y - centerY) /
                        centerY
                    ) * -2;


                const rotateY =
                    (
                        (x - centerX) /
                        centerX
                    ) * 2;


                card.style.transform =
                    `
                    translateY(-8px)
                    rotateX(${rotateX}deg)
                    rotateY(${rotateY}deg)
                    `;

            }
        );


        /* MOUSE LEAVE */

        card.addEventListener(
            "mouseleave",
            () => {

                card.style.transform =
                    "";

            }
        );

    }
);


/* =========================================================
   BOTON DE DESCARGA
   ========================================================= */

const downloadButton =
    document.querySelector(
        ".download-button"
    );


if (downloadButton) {

    downloadButton.addEventListener(
        "click",
        (event) => {

            event.preventDefault();


            /*
             * CUANDO TENGAS EL LINK REAL
             * DE DESCARGA DE LA APP,
             * PUEDES REEMPLAZAR EL ALERT
             * POR:
             *
             * window.location.href =
             * "TU-LINK-AQUI";
             */

            alert(
                "Pronto podrás descargar Recicla +."
            );

        }
    );

}


/* =========================================================
   NAVBAR AL HACER SCROLL
   ========================================================= */

const navbar =
    document.querySelector(
        ".navbar"
    );


window.addEventListener(
    "scroll",
    () => {

        if (
            window.scrollY > 80
        ) {

            navbar.style.boxShadow =
                `
                0 15px 50px
                rgba(22, 89, 49, 0.13)
                `;

        } else {

            navbar.style.boxShadow =
                `
                0 15px 50px
                rgba(22, 89, 49, 0.08)
                `;

        }

    }
);


/* =========================================================
   SMOOTH SCROLL
   ========================================================= */

document.querySelectorAll(
    'a[href^="#"]'
).forEach(
    (link) => {

        link.addEventListener(
            "click",
            (event) => {


                const targetId =
                    link.getAttribute(
                        "href"
                    );


                if (
                    !targetId ||
                    targetId === "#"
                ) {

                    return;

                }


                const target =
                    document.querySelector(
                        targetId
                    );


                if (!target) {

                    return;

                }


                event.preventDefault();


                target.scrollIntoView(
                    {
                        behavior: "smooth",
                        block: "start"
                    }
                );

            }
        );

    }
);


/* =========================================================
   MOVIMIENTO DEL TITULO DEL HERO
   ========================================================= */

const heroTitle =
    document.querySelector(
        ".hero h1"
    );


window.addEventListener(
    "mousemove",
    (event) => {

        if (
            !heroTitle ||
            window.innerWidth < 1000
        ) {

            return;

        }


        const x =
            event.clientX /
            window.innerWidth -
            0.5;


        const y =
            event.clientY /
            window.innerHeight -
            0.5;


        heroTitle.style.transform =
            `
            translate(
                ${x * -4}px,
                ${y * -4}px
            )
            `;

    }
);


/* =========================================================
   INICIO
   ========================================================= */

updateScrollProgress();