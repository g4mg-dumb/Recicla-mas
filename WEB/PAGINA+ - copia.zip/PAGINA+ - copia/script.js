const IMAGENES = {
    logo: "img/logo.png",
    hero: "img/hero.png",
    proyecto: "img/proyecto.png",
    app: "img/app-1.png",
    integrante1: "img/integrante-1.png",
    integrante2: "img/integrante-2.png",
    integrante3: "img/integrante-3.png",
    integrante4: "img/integrante-4.png"
};

function cargarImagen(id, ruta, placeholder = null) {
    const img = document.getElementById(id);
    if (!img) return;

    img.src = ruta;

    img.onload = () => {
        img.style.display = "block";
        if (placeholder) {
            const p = document.getElementById(placeholder);
            if (p) p.style.display = "none";
        }
    };
}

document.addEventListener("DOMContentLoaded", () => {
    cargarImagen("logoImg", IMAGENES.logo);
    cargarImagen("heroImg", IMAGENES.hero, "heroPlaceholder");
    cargarImagen("projectImg", IMAGENES.proyecto, "projectPlaceholder");
    cargarImagen("appImg", IMAGENES.app, "appPlaceholder");
    cargarImagen("member1Img", IMAGENES.integrante1);
    cargarImagen("member2Img", IMAGENES.integrante2);
    cargarImagen("member3Img", IMAGENES.integrante3);
    cargarImagen("member4Img", IMAGENES.integrante4);
});

const navbar = document.querySelector(".navbar");

window.addEventListener("scroll", () => {
    if (navbar) navbar.classList.toggle("scrolled", window.scrollY > 30);
});

const menuButton = document.querySelector(".menu-toggle");
const navLinks = document.querySelector(".nav-links");

if (menuButton) {
    menuButton.addEventListener("click", () => {
        navLinks.classList.toggle("active");
    });
}

const loginButton = document.querySelector(".login-btn");
const loginModal = document.getElementById("loginModal");
const closeLogin = document.getElementById("closeLogin");
const loginForm = document.getElementById("loginForm");
const successScreen = document.getElementById("successScreen");
const backHome = document.getElementById("backHome");

loginButton?.addEventListener("click", () => {
    loginModal.classList.add("active");
});

closeLogin?.addEventListener("click", () => {
    loginModal.classList.remove("active");
});

loginModal?.addEventListener("click", e => {
    if (e.target === loginModal) loginModal.classList.remove("active");
});

loginForm?.addEventListener("submit", e => {
    e.preventDefault();
    loginModal.classList.remove("active");

    setTimeout(() => {
        successScreen.classList.add("active");
    }, 250);
});

backHome?.addEventListener("click", () => {
    successScreen.classList.remove("active");
});

document.addEventListener("keydown", e => {
    if (e.key === "Escape") {
        loginModal?.classList.remove("active");
        successScreen?.classList.remove("active");
    }
});

document.querySelectorAll('a[href^="#"]').forEach(link => {
    link.addEventListener("click", e => {
        const target = document.querySelector(link.getAttribute("href"));

        if (target) {
            e.preventDefault();
            target.scrollIntoView({ behavior: "smooth" });
            navLinks?.classList.remove("active");
        }
    });
});

const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
        if (entry.isIntersecting) entry.target.classList.add("visible");
    });
}, { threshold: 0.15 });

document.querySelectorAll(".feature-card, .value-card, .team-card, .architecture-card").forEach(el => {
    observer.observe(el);
});