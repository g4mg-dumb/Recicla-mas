﻿package com.example.recicla

import android.content.pm.ActivityInfo
import android.graphics.Bitmap
import android.util.Log
import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.runtime.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.core.content.ContextCompat
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.recicla.ui.theme.ReciclaTheme
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.io.File
import java.io.FileOutputStream

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Forzar orientación vertical por código para mayor seguridad
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
        enableEdgeToEdge()
        setContent {
            val context = LocalContext.current
            val prefs = remember { context.getSharedPreferences("settings", Context.MODE_PRIVATE) }
            
            var appTheme by remember { 
                val savedTheme = prefs.getString("app_theme", AppTheme.SYSTEM.name)
                mutableStateOf(AppTheme.valueOf(savedTheme ?: AppTheme.SYSTEM.name))
            }

            var tipsEnabled by remember {
                mutableStateOf(prefs.getBoolean("tips_enabled", true))
            }

            var showTutorial by remember {
                mutableStateOf(prefs.getBoolean("show_tutorial", true))
            }

            val darkTheme = when (appTheme) {
                AppTheme.LIGHT -> false
                AppTheme.DARK -> true
                AppTheme.SYSTEM -> isSystemInDarkTheme()
            }

            ReciclaTheme(darkTheme = darkTheme) {
                val dbHelper = remember { DatabaseHelper(context) }
                
                ReciclaApp(
                    currentTheme = appTheme,
                    dbHelper = dbHelper,
                    onThemeChange = { newTheme ->
                        appTheme = newTheme
                        prefs.edit().putString("app_theme", newTheme.name).apply()
                    },
                    tipsEnabled = tipsEnabled,
                    onTipsEnabledChange = { enabled ->
                        tipsEnabled = enabled
                        prefs.edit().putBoolean("tips_enabled", enabled).apply()
                    },
                    showTutorial = showTutorial,
                    onShowTutorialChange = { enabled ->
                        showTutorial = enabled
                        prefs.edit().putBoolean("show_tutorial", enabled).apply()
                    }
                )
            }
        }
    }
}

@Composable
fun ReciclaApp(
    currentTheme: AppTheme,
    dbHelper: DatabaseHelper,
    onThemeChange: (AppTheme) -> Unit,
    tipsEnabled: Boolean,
    onTipsEnabledChange: (Boolean) -> Unit,
    showTutorial: Boolean,
    onShowTutorialChange: (Boolean) -> Unit
) {
    val navController = rememberNavController()
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val classifier = remember { ImageClassifierHelper(context) }

    val generalFacts = remember {
        listOf(
            "Reciclar una lata de aluminio ahorra un 95% de la energía necesaria para fabricar una nueva.",
            "El papel puede ser reciclado hasta 7 veces antes de que sus fibras se vuelvan demasiado débiles.",
            "Una botella de vidrio puede tardar hasta 4.000 años en biodegradarse en la naturaleza.",
            "Reciclar plástico ahorra el doble de energía que quemarlo en un incinerador.",
            "El reciclaje de una tonelada de papel salva 17 árboles maduros.",
            "Las pilas contienen metales pesados que pueden contaminar miles de litros de agua si no se reciclan.",
            "España recicla más del 70% de sus envases de vidrio."
        )
    }
    
    val randomFact = remember { generalFacts.random() }
    
    val searchInvalidInput = stringResource(R.string.search_invalid_input)
    val searchNoResults = stringResource(R.string.search_no_results)
    
    var capturedImageUri by remember { mutableStateOf<Uri?>(null) }
    var classificationResult by remember { mutableStateOf<RecyclingInfo?>(null) }
    var selectedDetailInfo by remember { mutableStateOf<RecyclingInfo?>(null) }

    DisposableEffect(Unit) {
        onDispose {
            classifier.close()
        }
    }

    val cameraLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.TakePicturePreview()
    ) { bitmap ->
        if (bitmap != null) {
            navController.navigate("loading")
            
            // Usamos el scope de Compose para procesar en segundo plano
            scope.launch {
                try {
                    // Agregamos un delay artificial para que el usuario vea la animación
                    delay(1200)
                    
                    val results = classifier.classify(bitmap)
                    
                    if (results.isNotEmpty() && results[0].score >= 0.70f) {
                        val topResult = results[0]
                        val label = topResult.label.lowercase().trim()
                        
                        if (label == "no basura") {
                            navController.navigate("error") {
                                popUpTo("loading") { inclusive = true }
                            }
                        } else {
                            val info = getRecyclingInfo(label, null)
                            if (info.objectName == "Desconocido") {
                                navController.navigate("error") {
                                    popUpTo("loading") { inclusive = true }
                                }
                            } else {
                                val uri = saveBitmapToCache(context, bitmap)
                                if (uri != null) {
                                    capturedImageUri = uri
                                    classificationResult = info.copy(capturedImageUri = capturedImageUri)
                                    
                                    // CRUD: CREATE - Guardar en historial automáticamente
                                    dbHelper.insertRecord(info.objectName, info.containerName)
                                    
                                    navController.navigate("result") {
                                        popUpTo("loading") { inclusive = true }
                                    }
                                } else {
                                    navController.navigate("error") {
                                        popUpTo("loading") { inclusive = true }
                                    }
                                }
                            }
                        }
                    } else {
                        navController.navigate("error") {
                            popUpTo("loading") { inclusive = true }
                        }
                    }
                } catch (e: Exception) {
                    navController.navigate("error") {
                        popUpTo("loading") { inclusive = true }
                    }
                }
            }
        }
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            cameraLauncher.launch(null)
        } else {
            Toast.makeText(context, "Permiso de cÃ¡mara denegado", Toast.LENGTH_SHORT).show()
        }
    }

    val startDestination = if (showTutorial) "how_to_use" else "main"

    NavHost(navController = navController, startDestination = startDestination) {
        composable("main") {
            MainScreen(
                fact = randomFact,
                tipsEnabled = tipsEnabled,
                onScanClick = {
                    val permissionCheckResult = ContextCompat.checkSelfPermission(
                        context, 
                        Manifest.permission.CAMERA
                    )
                    if (permissionCheckResult == PackageManager.PERMISSION_GRANTED) {
                        cameraLauncher.launch(null)
                    } else {
                        permissionLauncher.launch(Manifest.permission.CAMERA)
                    }
                },
                onHistoryClick = {
                    navController.navigate("history")
                },
                onSearch = { query ->
                    // Validación estricta: Solo letras y espacios, sin números
                    val isValid = query.isNotBlank() && query.all { it.isLetter() || it.isWhitespace() }
                    
                    if (!isValid) {
                        Toast.makeText(context, searchInvalidInput, Toast.LENGTH_SHORT).show()
                    } else {
                        val info = getRecyclingInfo(query, null)
                        if (info.objectName != "Desconocido") {
                            selectedDetailInfo = info
                            navController.navigate("material_detail")
                        } else {
                            Toast.makeText(context, searchNoResults, Toast.LENGTH_SHORT).show()
                        }
                    }
                },
                onInfoClick = {
                    navController.navigate("info")
                },
                onPointsClick = {
                    navController.navigate("points")
                },
                onHowToUseClick = {
                    navController.navigate("how_to_use")
                },
                onDevelopersClick = {
                    navController.navigate("developers")
                },
                onSettingsClick = {
                    navController.navigate("settings")
                }
            )
        }
        composable("settings") {
            SettingsScreen(
                currentTheme = currentTheme,
                onThemeChange = onThemeChange,
                tipsEnabled = tipsEnabled,
                onTipsEnabledChange = onTipsEnabledChange,
                showTutorial = showTutorial,
                onShowTutorialChange = onShowTutorialChange,
                onBack = { navController.popBackStack() }
            )
        }
        composable("result") {
            classificationResult?.let { info ->
                ResultScreen(
                    info = info,
                    onBack = { navController.popBackStack() },
                    onRetry = {
                        navController.popBackStack()
                        val permissionCheckResult = ContextCompat.checkSelfPermission(
                            context, 
                            Manifest.permission.CAMERA
                        )
                        if (permissionCheckResult == PackageManager.PERMISSION_GRANTED) {
                            cameraLauncher.launch(null)
                        } else {
                            permissionLauncher.launch(Manifest.permission.CAMERA)
                        }
                    },
                    onHome = {
                        navController.navigate("main") {
                            popUpTo("main") { inclusive = true }
                        }
                    }
                )
            }
        }
        composable("error") {
            ErrorScreen(
                onBack = { 
                    navController.navigate("main") {
                        popUpTo("main") { inclusive = true }
                    }
                },
                onTryAgain = {
                    navController.popBackStack()
                    val permissionCheckResult = ContextCompat.checkSelfPermission(
                        context, 
                        Manifest.permission.CAMERA
                    )
                    if (permissionCheckResult == PackageManager.PERMISSION_GRANTED) {
                        cameraLauncher.launch(null)
                    } else {
                        permissionLauncher.launch(Manifest.permission.CAMERA)
                    }
                },
                onHome = {
                    navController.navigate("main") {
                        popUpTo("main") { inclusive = true }
                    }
                }
            )
        }
        composable("info") {
            InfoScreen(
                onBack = { navController.popBackStack() },
                onLibraryClick = { navController.navigate("library") }
            )
        }
        composable("library") {
            MaterialLibraryScreen(
                onBack = { navController.popBackStack() },
                onMaterialClick = { label ->
                    val info = getRecyclingInfo(label, null)
                    selectedDetailInfo = info
                    navController.navigate("material_detail")
                }
            )
        }
        composable("material_detail") {
            selectedDetailInfo?.let { info ->
                MaterialDetailScreen(
                    info = info,
                    onBack = { navController.popBackStack() }
                )
            }
        }
        composable("history") {
            HistoryScreen(
                dbHelper = dbHelper,
                onBack = { navController.popBackStack() }
            )
        }
        composable("points") {
            PointsScreen(onBack = { navController.popBackStack() })
        }
        composable("developers") {
            DevelopersScreen(onBack = { navController.popBackStack() })
        }
        composable("how_to_use") {
            HowToUseScreen(onBack = { 
                if (navController.previousBackStackEntry != null) {
                    navController.popBackStack()
                } else {
                    navController.navigate("main") {
                        popUpTo("how_to_use") { inclusive = true }
                    }
                }
            })
        }
        composable("loading") {
            LoadingScreen()
        }
    }
}

/**
 * Guarda un Bitmap en el directorio de caché interno de la aplicación.
 * Esto evita que las imágenes aparezcan en la galería del usuario.
 */
private fun saveBitmapToCache(context: Context, bitmap: Bitmap): Uri? {
    return try {
        val imagesFolder = File(context.cacheDir, "images")
        if (!imagesFolder.exists()) {
            imagesFolder.mkdirs()
        }
        val file = File(imagesFolder, "captured_image_${System.currentTimeMillis()}.jpg")
        val stream = FileOutputStream(file)
        bitmap.compress(Bitmap.CompressFormat.JPEG, 90, stream)
        stream.flush()
        stream.close()
        Uri.fromFile(file)
    } catch (e: Exception) {
        Log.e("ReciclaAI", "Error al guardar imagen en caché: ${e.message}")
        null
    }
}

fun getRecyclingInfo(label: String, uri: Uri?): RecyclingInfo {
    // Normalizar: quitar acentos y pasar a minúsculas para mayor robustez
    val l = label.lowercase()
        .replace("á", "a")
        .replace("é", "e")
        .replace("í", "i")
        .replace("ó", "o")
        .replace("ú", "u")

    return when {
        l.contains("plastico") -> RecyclingInfo(
            objectName = "Plástico",
            residueType = "Envases de plástico, latas y envases tipo brik",
            containerName = "Contenedor AMARILLO",
            containerColor = Color(0xFFFFEB3B),
            instructions = "Enjuaga los envases si tienen restos. Aplástalos para ahorrar espacio. Incluye botellas, tarrinas y bolsas.",
            capturedImageUri = uri,
            didYouKnow = "Reciclar plástico ahorra hasta un 84% de la energía necesaria para producir plástico virgen."
        )
        l.contains("papel") -> RecyclingInfo(
            objectName = "Papel",
            residueType = "Papeles y hojas",
            containerName = "Contenedor AZUL",
            containerColor = Color(0xFF2196F3),
            instructions = "Asegúrate de que el papel no tenga manchas de grasa o comida. Quita grapas si es posible.",
            capturedImageUri = uri,
            didYouKnow = "Por cada tonelada de papel reciclado, se ahorran 26.000 litros de agua."
        )
        l.contains("carton") -> RecyclingInfo(
            objectName = "Cartón",
            residueType = "Cajas y envases de cartón",
            containerName = "Contenedor AZUL",
            containerColor = Color(0xFF2196F3),
            instructions = "Pliega las cajas de cartón para que ocupen menos espacio. Retira restos de precinto plástico.",
            capturedImageUri = uri,
            didYouKnow = "El cartón reciclado mantiene el 75% de la resistencia del cartón virgen."
        )
        l.contains("vidrio") -> RecyclingInfo(
            objectName = "Vidrio",
            residueType = "Botellas, frascos y tarros de vidrio",
            containerName = "Contenedor VERDE",
            containerColor = Color(0xFF4CAF50),
            instructions = "Quita los tapones y las tapas. Solo envases de vidrio, no deposites cristal (espejos, vasos, bombillas).",
            capturedImageUri = uri,
            didYouKnow = "El vidrio es 100% reciclable y puede ser reciclado infinitas veces sin perder calidad."
        )
        l.contains("metal") -> RecyclingInfo(
            objectName = "Metal",
            residueType = "Envases metálicos, latas y aluminio",
            containerName = "Contenedor AMARILLO",
            containerColor = Color(0xFFFFEB3B),
            instructions = "Limpia los envases para eliminar restos de comida o bebida antes de reciclarlos.",
            capturedImageUri = uri,
            didYouKnow = "Reciclar una sola lata de aluminio ahorra energía suficiente para hacer funcionar un televisor durante 3 horas."
        )
        l.contains("organico") -> RecyclingInfo(
            objectName = "Orgánico",
            residueType = "Restos de comida y materia biodegradable",
            containerName = "Contenedor MARRÓN",
            containerColor = Color(0xFF795548),
            instructions = "Deposita los residuos orgánicos en bolsas biodegradables cuando sea posible",
            capturedImageUri = uri,
            didYouKnow = "Los residuos orgánicos pueden convertirse en compost para nutrir plantas y cultivos."
        )
        else -> RecyclingInfo(
            objectName = "Desconocido",
            residueType = "N/A",
            containerName = "N/A",
            containerColor = Color.Gray,
            instructions = "N/A",
            capturedImageUri = uri
        )
    }
}
