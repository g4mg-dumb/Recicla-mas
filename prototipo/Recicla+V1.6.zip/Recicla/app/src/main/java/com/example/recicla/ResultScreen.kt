﻿package com.example.recicla

import android.net.Uri
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.Replay
import androidx.compose.material.icons.filled.Recycling
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.TextButton
import android.widget.Toast
import androidx.compose.material.icons.filled.ThumbUp
import androidx.compose.material.icons.filled.ThumbDown
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.request.ImageRequest

/**
 * Modelo de datos para representar un tipo de residuo.
 */
data class RecyclingInfo(
    val objectName: String,
    val residueType: String,
    val containerName: String,
    val containerColor: Color,
    val instructions: String,
    val capturedImageUri: Uri? = null,
    val didYouKnow: String = ""
)

/**
 * Pantalla dinÃ¡mica que muestra el resultado de la detecciÃ³n.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ResultScreen(
    info: RecyclingInfo,
    onBack: () -> Unit,
    onRetry: () -> Unit,
    onHome: () -> Unit
) {
    val context = LocalContext.current
    val colorScheme = MaterialTheme.colorScheme
    val typography = MaterialTheme.typography
    var feedbackGiven by remember { mutableStateOf(false) }
    
    // Detectamos si es amarillo
    val isYellow = info.containerColor == Color(0xFFFFD60A)
    
    // Color de alto contraste para textos e iconos sobre fondo claro
    val contrastColor = if (isYellow) Color(0xFF916F00) else info.containerColor

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = {
                    Text(
                        text = stringResource(R.string.screen_result_title),
                        color = Color.White,
                        style = typography.titleLarge
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = null, tint = Color.White)
                    }
                },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    containerColor = colorScheme.primary
                )
            )
        },
        containerColor = colorScheme.background
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 24.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Contenido envuelto en una columna con peso flexible para empujar el botón al fondo si hay espacio
            Column(
                modifier = Modifier.weight(1f, fill = false),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Spacer(modifier = Modifier.height(20.dp))

                // Imagen del objeto (La foto real capturada)
                Box(
                    modifier = Modifier
                        .size(220.dp)
                        .clip(RoundedCornerShape(24.dp))
                        .background(colorScheme.surface)
                        .border(1.dp, colorScheme.outline.copy(alpha = 0.5f), RoundedCornerShape(24.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    if (info.capturedImageUri != null) {
                        AsyncImage(
                            model = ImageRequest.Builder(LocalContext.current)
                                .data(info.capturedImageUri)
                                .crossfade(true)
                                .build(),
                            contentDescription = "Foto capturada",
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Crop
                        )
                    } else {
                        Icon(
                            imageVector = Icons.Default.Delete,
                            contentDescription = null,
                            modifier = Modifier.size(80.dp),
                            tint = Color.LightGray
                        )
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))

                // Nombre del objeto detectado
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Objeto detectado:",
                            style = typography.labelSmall,
                            color = colorScheme.onSurface.copy(alpha = 0.6f)
                        )
                        Text(
                            text = info.objectName.uppercase(),
                            style = typography.headlineLarge, // Más grande
                            color = contrastColor,
                            fontWeight = FontWeight.Black
                        )
                    }
                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = null,
                        tint = colorScheme.secondary,
                        modifier = Modifier.size(40.dp) // Icono más grande
                    )
                }

                Spacer(modifier = Modifier.height(24.dp))

                // Tarjetas de información
                InfoRow(
                    icon = Icons.Default.Recycling,
                    label = "Tipo de residuo: ",
                    value = info.residueType,
                    iconColor = contrastColor
                )
                
                Spacer(modifier = Modifier.height(12.dp))

                val cardContentColor = if (isYellow) com.example.recicla.ui.theme.DarkGreen else Color.White
                
                InfoRow(
                    icon = Icons.Default.Delete,
                    label = "Depositar en: ",
                    value = info.containerName,
                    iconColor = contrastColor,
                    isContainerRow = true,
                    cardBackgroundColor = if (isYellow) info.containerColor else info.containerColor,
                    contentColor = cardContentColor
                )

                Spacer(modifier = Modifier.height(12.dp))

                InfoRow(
                    icon = Icons.Default.Lightbulb,
                    label = "¿Cómo reciclar?",
                    value = info.instructions,
                    iconColor = contrastColor
                )

                if (info.didYouKnow.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(24.dp))
                    DidYouKnowSection(info.didYouKnow)
                }

                Spacer(modifier = Modifier.height(32.dp))

                FeedbackSection(
                    feedbackGiven = feedbackGiven,
                    onFeedback = {
                        feedbackGiven = true
                        Toast.makeText(context, context.getString(R.string.feedback_thanks), Toast.LENGTH_SHORT).show()
                    }
                )

                Spacer(modifier = Modifier.height(32.dp))
            }

            // Botón principal (Reintentar o Volver)
            val isFromCamera = info.capturedImageUri != null
            
            Button(
                onClick = if (isFromCamera) onRetry else onBack,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = colorScheme.primary
                ),
                shape = RoundedCornerShape(28.dp)
            ) {
                Icon(
                    if (isFromCamera) Icons.Default.Replay else Icons.Default.ArrowBack, 
                    contentDescription = null, 
                    tint = Color.White
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = if (isFromCamera) stringResource(R.string.action_try_again) else "VOLVER",
                    style = typography.bodyLarge.copy(fontWeight = FontWeight.Bold),
                    color = Color.White
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Botón Volver al inicio
            OutlinedButton(
                onClick = onHome,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp)
                    .padding(bottom = 16.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, colorScheme.primary),
                shape = RoundedCornerShape(28.dp)
            ) {
                Text(
                    text = stringResource(R.string.action_go_home),
                    style = typography.bodyLarge.copy(fontWeight = FontWeight.Bold),
                    color = colorScheme.primary
                )
            }
        }
    }
}

@Composable
fun DidYouKnowSection(fact: String) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.4f)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    Icons.Default.Lightbulb,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = stringResource(R.string.did_you_know_title),
                    style = MaterialTheme.typography.titleSmall,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.Bold
                )
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = fact,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSecondaryContainer
            )
        }
    }
}

@Composable
fun FeedbackSection(
    feedbackGiven: Boolean,
    onFeedback: () -> Unit
) {
    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = if (feedbackGiven) stringResource(R.string.feedback_thanks) else stringResource(R.string.feedback_title),
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f),
            textAlign = TextAlign.Center
        )
        
        if (!feedbackGiven) {
            Spacer(modifier = Modifier.height(12.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Center
            ) {
                IconButton(onClick = onFeedback) {
                    Icon(
                        Icons.Default.ThumbUp,
                        contentDescription = "Correcto",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(28.dp)
                    )
                }
                Spacer(modifier = Modifier.width(24.dp))
                IconButton(onClick = onFeedback) {
                    Icon(
                        Icons.Default.ThumbDown,
                        contentDescription = "Incorrecto",
                        tint = MaterialTheme.colorScheme.error,
                        modifier = Modifier.size(28.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun InfoRow(
    icon: ImageVector,
    label: String,
    value: String,
    iconColor: Color,
    isContainerRow: Boolean = false,
    cardBackgroundColor: Color = MaterialTheme.colorScheme.surface,
    contentColor: Color = MaterialTheme.colorScheme.onSurface
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        color = if (isContainerRow) cardBackgroundColor else MaterialTheme.colorScheme.surface,
        shadowElevation = 3.dp
    ) {
        Row(
            modifier = Modifier.padding(18.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .background(
                        if (isContainerRow) contentColor.copy(alpha = 0.1f) else iconColor.copy(alpha = 0.15f), 
                        CircleShape
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = if (isContainerRow) contentColor else iconColor,
                    modifier = Modifier.size(28.dp)
                )
            }
            
            Spacer(modifier = Modifier.width(18.dp))

            Column {
                Text(
                    text = label,
                    style = MaterialTheme.typography.labelMedium,
                    color = if (isContainerRow) contentColor.copy(alpha = 0.7f) else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f),
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = value,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Black,
                    color = if (isContainerRow) contentColor else MaterialTheme.colorScheme.onSurface
                )
            }
        }
    }
}
