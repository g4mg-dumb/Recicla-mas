# Walkthrough: Menú de Configuración y Sección de Contacto

He actualizado el menú lateral (Navigation Drawer) para incluir la opción de configuración y una nueva sección de contacto detallada, elevando el profesionalismo de Recicla+.

## Cambios Realizados

### Nueva Navegación
* **Item de Configuración:** Se añadió "Configuración" entre Inicio y Desarrolladores en el menú lateral. Al pulsarlo, se muestra un mensaje de "Próximamente" para gestionar las expectativas del usuario.
* **Separación Visual:** Se incluyó un divisor horizontal y un espacio flexible para organizar mejor las opciones de navegación frente a la información de contacto.

### Sección de Contacto Profesional
Se implementó una nueva sección en la parte inferior del menú que incluye:
* **Título "CONTACTO":** Con un estilo sutil pero legible.
* **Canales de Comunicación:**
    * 📧 **Email:** reciclamasproyecto@gmail.com
    * 📸 **Instagram:** reciclamas.app
    * 🎵 **TikTok:** @reciclamasproyecto
* **Iconografía Coherente:** Se utilizaron iconos de Material Design que coinciden con el estilo visual de la aplicación.

## Verificación

1.  **Orden del Menú:** Se verificó visualmente que la opción de Configuración esté correctamente posicionada.
2.  **Interactividad:** El clic en Configuración dispara un Toast funcional en [MainActivity.kt](file:///C:/Users/gabo/Desktop/Recicla/app/src/main/java/com/example/recicla/MainActivity.kt).
3.  **Estética:** La sección de contacto se ajusta al fondo y usa la paleta de verdes (DarkGreen) definida en el tema.

> [!TIP]
> Esta actualización no solo mejora la utilidad del menú, sino que también facilita que los usuarios y posibles colaboradores se pongan en contacto con el equipo de Recicla+, fortaleciendo la comunidad en torno al proyecto.
