# Plan de Implementación: Rediseño de la Pantalla de Información

Este plan busca mejorar la claridad y coherencia visual de la pantalla de información, reemplazando bloques basados en imágenes por componentes nativos de Jetpack Compose y optimizando la jerarquía de la información.

## User Review Required

> [!IMPORTANT]
> Se propone eliminar las imágenes que contienen texto (como "¿Qué es Recicla+?" o el grid de basureros) y reemplazarlas por texto nativo y tarjetas. Esto mejorará la legibilidad, la accesibilidad y hará que la pantalla se sienta más integrada con el resto de la app.

## Proposed Changes

### [Interfaz de Usuario - InfoScreen]

#### [MODIFY] [InfoScreen.kt](file:///C:/Users/gabo/Desktop/Recicla/app/src/main/java/com/example/recicla/InfoScreen.kt)
* **Simplificación del Layout:** Cambiar el scroll vertical pesado por una estructura de tarjetas limpias y bien espaciadas.
* **Nativización de Contenidos:**
    * Reemplazar `info_what_is` por una sección de texto con tipografía `headlineSmall` y `bodyLarge`.
    * Reemplazar `info_bins_grid` por un grid nativo de componentes de color, mostrando claramente qué va en cada contenedor.
* **Mejora de Estilos:**
    * Modificar `InfoBox` para usar elevación suave (`shadowElevation`) y bordes más finos en lugar del borde de 2dp actual.
    * Unificar los radios de las esquinas a `24.dp` para que coincidan con los botones principales de la app.
* **Optimización de Espaciado:** Aumentar el `Spacer` entre secciones para que la información no se sienta amontonada.

## Verification Plan

### Manual Verification
* Navegar a la pantalla de "Información" y verificar que el texto sea nítido y fácil de leer.
* Comprobar que el diseño de los contenedores de reciclaje (colores) se vea moderno y coherente con el resto de la app.
* Asegurar que el scroll sea fluido y que no haya elementos cortados en pantallas pequeñas.
