# Tareas: Pulido Visual y Feedback en Tiempo Real

- `[x]` Actualizar `Color.kt` con la paleta de marca.
- `[x]` Configurar jerarquía tipográfica en `Type.kt`.
- `[x]` Aplicar esquema de colores y tipografía en `Theme.kt`.
- `[x]` Crear `LoadingScreen.kt`.
- `[x]` Integrar `LoadingScreen` en el `NavHost` de `MainActivity.kt`.
- `[x]` Refactorizar `MainScreen.kt` para usar estilos del tema.
- `[x]` Refactorizar `ResultScreen.kt` para usar estilos del tema.
- `[x]` Refactorizar `ErrorScreen.kt` para usar estilos del tema.
- `[x]` Refactorizar pantallas adicionales (`Developers`, `HowToUse`).
- `[x]` Añadir item "Configuración" al menú lateral en `MainScreen.kt`.
- `[x]` Implementar sección de "Contacto" en `MainScreen.kt`.
- `[x]` Manejar click de Configuración en `MainActivity.kt` con un Toast.
- `[x]` Rediseñar `InfoScreen.kt`:
    - `[x]` Reemplazar imágenes de texto por componentes nativos.
    - `[x]` Crear grid de contenedores de reciclaje nativo.
    - `[x]` Aplicar nuevos estilos de tarjetas y espaciado.
- `[x]` Verificación final y limpieza de código.
