﻿package com.example.recicla

import android.content.Context
import android.graphics.Bitmap
import org.tensorflow.lite.DataType
import org.tensorflow.lite.Interpreter
import org.tensorflow.lite.support.common.FileUtil
import org.tensorflow.lite.support.common.ops.NormalizeOp
import org.tensorflow.lite.support.image.ImageProcessor
import org.tensorflow.lite.support.image.TensorImage
import org.tensorflow.lite.support.label.Category
import org.tensorflow.lite.support.tensorbuffer.TensorBuffer
import java.nio.MappedByteBuffer

class ImageClassifierHelper(
    private val context: Context,
    private val modelName: String = "model_unquant.tflite",
    private val labelName: String = "labels.txt"
) {
    private var interpreter: Interpreter? = null
    private var labels: List<String> = emptyList()
    private var inputImageWidth = 0
    private var inputImageHeight = 0
    private var inputDataType: DataType = DataType.FLOAT32

    init {
        setupInterpreter()
    }

    private fun setupInterpreter() {
        val model: MappedByteBuffer = FileUtil.loadMappedFile(context, modelName)
        val options = Interpreter.Options()
        interpreter = Interpreter(model, options)

        val inputShape = interpreter?.getInputTensor(0)?.shape() // {1, height, width, 3}
        inputImageHeight = inputShape?.get(1) ?: 224
        inputImageWidth = inputShape?.get(2) ?: 224
        inputDataType = interpreter?.getInputTensor(0)?.dataType() ?: DataType.FLOAT32

        labels = FileUtil.loadLabels(context, labelName).map { it.substringAfter(" ").trim() }
    }

    fun classify(bitmap: Bitmap): List<Category> {
        if (interpreter == null) setupInterpreter()

        // Redimensionar manualmente para evitar problemas con ResizeOp
        val resizedBitmap = Bitmap.createScaledBitmap(bitmap, inputImageWidth, inputImageHeight, true)

        val imageProcessor = ImageProcessor.Builder()
            // Los modelos unquantized de Teachable Machine suelen esperar el rango [-1, 1].
            // NormalizeOp(mean, std) -> (valor - mean) / std.
            // Para obtener [-1, 1] desde [0, 255]: (pixel - 127.5f) / 127.5f.
            .add(NormalizeOp(127.5f, 127.5f))
            .build()

        var tensorImage = TensorImage(inputDataType)
        tensorImage.load(resizedBitmap)
        tensorImage = imageProcessor.process(tensorImage)

        val outputShape = interpreter?.getOutputTensor(0)?.shape() // {1, num_labels}
        val outputDataType = interpreter?.getOutputTensor(0)?.dataType() ?: DataType.FLOAT32
        val outputBuffer = TensorBuffer.createFixedSize(outputShape, outputDataType)

        interpreter?.run(tensorImage.buffer, outputBuffer.buffer.rewind())

        val results = mutableListOf<Category>()
        val outputArray = outputBuffer.floatArray
        for (i in labels.indices) {
            if (i < outputArray.size) {
                results.add(Category(labels[i], outputArray[i]))
            }
        }

        return results.sortedByDescending { it.score }
    }

    fun close() {
        interpreter?.close()
        interpreter = null
    }
}
