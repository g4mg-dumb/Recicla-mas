package com.example.recicla.ui.theme

import androidx.compose.ui.graphics.Color

val DarkGreen = Color(0xFF2D6A4F)
val LightGreen = Color(0xFF74A15E)
val AppBackground = Color(0xFFF1F7ED)
val RecyclingYellow = Color(0xFFFFD60A)
val RecyclingBlue = Color(0xFF0077B6)
val RecyclingBrown = Color(0xFF6D4C41)
val RecyclingErrorRed = Color(0xFFE63946)