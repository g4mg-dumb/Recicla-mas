package com.example.recicla

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

data class LibraryCategory(
    val name: String,
    val icon: ImageVector,
    val color: Color,
    val label: String // Para buscar en getRecyclingInfo
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MaterialLibraryScreen(
    onBack: () -> Unit,
    onMaterialClick: (String) -> Unit
) {
    val categories = listOf(
        LibraryCategory("Plástico", Icons.Default.Inventory, Color(0xFFFFD60A), "plastico"),
        LibraryCategory("Papel", Icons.Default.Description, Color(0xFF0077B6), "papel"),
        LibraryCategory("Cartón", Icons.Default.AllInbox, Color(0xFF0077B6), "carton"),
        LibraryCategory("Vidrio", Icons.Default.LocalBar, Color(0xFF2D6A4F), "vidrio"),
        LibraryCategory("Metal", Icons.Default.Kitchen, Color(0xFFFFD60A), "metal"),
        LibraryCategory("Orgánico", Icons.Default.Eco, Color(0xFF6D4C41), "organico")
    )

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = { Text("GUÍA POR MATERIAL", color = Color.White) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = null, tint = Color.White)
                    }
                },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary
                )
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp)
        ) {
            Text(
                text = "Selecciona un material para aprender cómo reciclarlo correctamente:",
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.7f),
                modifier = Modifier.padding(bottom = 24.dp, start = 8.dp)
            )

            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                horizontalArrangement = Arrangement.spacedBy(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(categories) { category ->
                    MaterialCard(category) {
                        onMaterialClick(category.label)
                    }
                }
            }
        }
    }
}

@Composable
fun MaterialCard(category: LibraryCategory, onClick: () -> Unit) {
    // Tono más oscuro y legible para el texto/icono si es amarillo
    val isYellow = category.color == Color(0xFFFFD60A)
    val contrastColor = if (isYellow) Color(0xFF916F00) else category.color
    
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .height(160.dp) // Un poco más alto
            .clickable { onClick() },
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 6.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Box(
                modifier = Modifier
                    .size(70.dp) // Icono más grande
                    .background(category.color.copy(alpha = 0.15f), RoundedCornerShape(20.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = category.icon,
                    contentDescription = null,
                    tint = contrastColor,
                    modifier = Modifier.size(36.dp)
                )
            }
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                text = category.name.uppercase(),
                style = MaterialTheme.typography.titleLarge, // Más grande
                fontWeight = FontWeight.Black, // Más negrita
                color = contrastColor, // Color con contraste
                textAlign = TextAlign.Center,
                letterSpacing = 1.sp
            )
        }
    }
}
