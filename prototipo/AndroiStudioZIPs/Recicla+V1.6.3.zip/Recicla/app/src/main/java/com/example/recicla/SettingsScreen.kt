package com.example.recicla

import androidx.compose.ui.res.stringResource
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.selection.selectableGroup
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.MenuBook
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import java.io.File

enum class AppTheme {
    LIGHT, DARK, SYSTEM
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    currentTheme: AppTheme,
    onThemeChange: (AppTheme) -> Unit,
    tipsEnabled: Boolean,
    onTipsEnabledChange: (Boolean) -> Unit,
    showTutorial: Boolean,
    onShowTutorialChange: (Boolean) -> Unit,
    onBack: () -> Unit
) {
    val colorScheme = MaterialTheme.colorScheme
    val typography = MaterialTheme.typography
    val context = LocalContext.current
    var showThemeDialog by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = {
                    Text(
                        text = "Configuración",
                        color = Color.White,
                        style = typography.titleLarge
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Volver",
                            tint = Color.White
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = colorScheme.primary
                )
            )
        },
        containerColor = colorScheme.background
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
        ) {
            SettingsSectionTitle(title = "Apariencia")
            
            SettingsItem(
                icon = Icons.Default.Palette,
                title = "Tema de la aplicación",
                subtitle = when(currentTheme) {
                    AppTheme.LIGHT -> "Claro"
                    AppTheme.DARK -> "Oscuro"
                    AppTheme.SYSTEM -> "Predeterminado del sistema"
                },
                onClick = { showThemeDialog = true }
            )
            
            SettingsItemWithSwitch(
                icon = Icons.Default.Notifications,
                title = stringResource(R.string.settings_notifications_title),
                subtitle = stringResource(R.string.settings_notifications_desc),
                checked = tipsEnabled,
                onCheckedChange = onTipsEnabledChange
            )

            SettingsItemWithSwitch(
                icon = Icons.AutoMirrored.Filled.MenuBook,
                title = "Tutorial de inicio",
                subtitle = "Mostrar la guía de uso al abrir la aplicación",
                checked = showTutorial,
                onCheckedChange = onShowTutorialChange
            )

            Spacer(modifier = Modifier.height(24.dp))
            SettingsSectionTitle(title = "Datos y Almacenamiento")

            val cacheCleanedMsg = stringResource(R.string.cache_cleaned)
            
            SettingsItem(
                icon = Icons.Default.DeleteSweep,
                title = "Limpiar caché de imágenes",
                subtitle = "Elimina las fotos temporales de los escaneos",
                onClick = {
                    val cacheDir = File(context.cacheDir, "images")
                    if (cacheDir.exists()) {
                        cacheDir.deleteRecursively()
                        Toast.makeText(context, cacheCleanedMsg, Toast.LENGTH_SHORT).show()
                    }
                }
            )

            Spacer(modifier = Modifier.height(24.dp))
            SettingsSectionTitle(title = "Comunidad y Ayuda")

            val shareTitle = stringResource(R.string.settings_share_title)
            val shareDesc = stringResource(R.string.settings_share_desc)
            val shareText = stringResource(R.string.share_text)
            
            SettingsItem(
                icon = Icons.Default.Share,
                title = shareTitle,
                subtitle = shareDesc,
                onClick = {
                    val sendIntent: Intent = Intent().apply {
                        action = Intent.ACTION_SEND
                        putExtra(Intent.EXTRA_TEXT, shareText)
                        type = "text/plain"
                    }
                    val shareIntent = Intent.createChooser(sendIntent, null)
                    context.startActivity(shareIntent)
                }
            )

            val contactTitle = stringResource(R.string.settings_contact_title)
            val contactDesc = stringResource(R.string.settings_contact_desc)
            
            SettingsItem(
                icon = Icons.Default.Email,
                title = contactTitle,
                subtitle = contactDesc,
                onClick = {
                    val intent = Intent(Intent.ACTION_SENDTO).apply {
                        data = Uri.parse("mailto:reciclamasproyecto@gmail.com")
                        putExtra(Intent.EXTRA_SUBJECT, "Soporte Recicla+")
                    }
                    try {
                        context.startActivity(intent)
                    } catch (e: Exception) {
                        Toast.makeText(context, "No hay aplicaciones de correo instaladas", Toast.LENGTH_SHORT).show()
                    }
                }
            )

            Spacer(modifier = Modifier.height(24.dp))
            SettingsSectionTitle(title = "Acerca de")

            SettingsItem(
                icon = Icons.Default.Info,
                title = "Versión de la aplicación",
                subtitle = "1.3.0-beta (Recicla+ AI)",
                onClick = {}
            )

            SettingsItem(
                icon = Icons.Default.Description,
                title = "Licencias de software",
                subtitle = "Bibliotecas de código abierto utilizadas",
                onClick = {}
            )
        }
    }

    if (showThemeDialog) {
        AlertDialog(
            onDismissRequest = { showThemeDialog = false },
            title = { Text("Seleccionar Tema") },
            text = {
                Column(Modifier.selectableGroup()) {
                    ThemeOption(
                        text = "Claro",
                        selected = currentTheme == AppTheme.LIGHT,
                        onClick = { onThemeChange(AppTheme.LIGHT); showThemeDialog = false }
                    )
                    ThemeOption(
                        text = "Oscuro",
                        selected = currentTheme == AppTheme.DARK,
                        onClick = { onThemeChange(AppTheme.DARK); showThemeDialog = false }
                    )
                    ThemeOption(
                        text = "Predeterminado del sistema",
                        selected = currentTheme == AppTheme.SYSTEM,
                        onClick = { onThemeChange(AppTheme.SYSTEM); showThemeDialog = false }
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = { showThemeDialog = false }) {
                    Text("Cancelar")
                }
            }
        )
    }
}

@Composable
fun SettingsSectionTitle(title: String) {
    Text(
        text = title,
        style = MaterialTheme.typography.labelLarge,
        color = MaterialTheme.colorScheme.primary,
        fontWeight = FontWeight.Bold,
        modifier = Modifier.padding(bottom = 12.dp, start = 8.dp)
    )
}

@Composable
fun SettingsItem(
    icon: ImageVector,
    title: String,
    subtitle: String,
    onClick: () -> Unit
) {
    Surface(
        onClick = onClick,
        color = Color.Transparent,
        modifier = Modifier.fillMaxWidth()
    ) {
        SettingsItemContent(icon, title, subtitle)
    }
}

@Composable
fun SettingsItemWithSwitch(
    icon: ImageVector,
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Surface(
        onClick = { onCheckedChange(!checked) },
        color = Color.Transparent,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Box(modifier = Modifier.weight(1f)) {
                SettingsItemContent(icon, title, subtitle)
            }
            Switch(
                checked = checked,
                onCheckedChange = onCheckedChange,
                modifier = Modifier.padding(end = 8.dp)
            )
        }
    }
}

@Composable
fun SettingsItemContent(
    icon: ImageVector,
    title: String,
    subtitle: String
) {
    Row(
        modifier = Modifier
            .padding(vertical = 12.dp, horizontal = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(24.dp)
        )
        Spacer(modifier = Modifier.width(16.dp))
        Column {
            Text(
                text = title,
                style = MaterialTheme.typography.bodyLarge,
                fontWeight = FontWeight.SemiBold
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodyMedium,
                color = Color.Gray
            )
        }
    }
}

@Composable
fun ThemeOption(
    text: String,
    selected: Boolean,
    onClick: () -> Unit
) {
    Row(
        Modifier
            .fillMaxWidth()
            .height(56.dp)
            .selectable(
                selected = selected,
                onClick = onClick,
                role = Role.RadioButton
            )
            .padding(horizontal = 16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        RadioButton(
            selected = selected,
            onClick = null // null because the row is selectable
        )
        Text(
            text = text,
            style = MaterialTheme.typography.bodyLarge,
            modifier = Modifier.padding(start = 16.dp)
        )
    }
}
