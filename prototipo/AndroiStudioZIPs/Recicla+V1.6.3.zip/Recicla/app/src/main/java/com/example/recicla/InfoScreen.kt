package com.example.recicla

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Recycling
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun InfoScreen(
    onBack: () -> Unit,
    onLibraryClick: () -> Unit
) {
    val colorScheme = MaterialTheme.colorScheme
    val typography = MaterialTheme.typography

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = {
                    Text(
                        text = "Información",
                        color = Color.White,
                        style = typography.titleLarge
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Volver",
                            tint = Color.White
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = colorScheme.primary
                )
            )
        },
        containerColor = colorScheme.background
    ) { innerPadding ->
        Box(modifier = Modifier.fillMaxSize().padding(innerPadding)) {
            // Fondo sutil decorativo
            Image(
                painter = painterResource(id = R.drawable.info_bg),
                contentDescription = null,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop,
                alpha = 0.4f
            )

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Banner de Bienvenida Nativo
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = colorScheme.primary)
                ) {
                    Row(
                        modifier = Modifier.padding(24.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Bienvenido a",
                                style = typography.titleMedium,
                                color = Color.White.copy(alpha = 0.9f)
                            )
                            Text(
                                text = "Recicla+",
                                style = typography.headlineLarge,
                                color = Color.White
                            )
                        }
                        Icon(
                            imageVector = Icons.Default.Recycling,
                            contentDescription = null,
                            tint = Color.White.copy(alpha = 0.2f),
                            modifier = Modifier.size(60.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))

                // ¿Qué es Recicla+? (Nativo)
                InfoSection(title = "¿QUÉ ES RECICLA+?") {
                    Text(
                        text = "Recicla+ es una herramienta inteligente diseñada para ayudarte a identificar y separar tus residuos de forma correcta dentro de nuestro liceo.",
                        style = typography.bodyLarge,
                        color = colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Button(
                        onClick = onLibraryClick,
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = colorScheme.primary)
                    ) {
                        Icon(Icons.Default.Recycling, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("VER GUÍA POR MATERIAL", fontWeight = FontWeight.Bold)
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))

                // Guía de Contenedores (Nativo y Visual)
                InfoSection(title = "GUÍA DE CONTENEDORES") {
                    Text(
                        text = "Identifica el color para reciclar correctamente:",
                        style = typography.bodyMedium,
                        color = colorScheme.onSurface.copy(alpha = 0.6f),
                        modifier = Modifier.padding(bottom = 16.dp)
                    )
                    
                    BinInfoRow(color = Color(0xFFFFD60A), title = "AMARILLO", description = "Plásticos y latas")
                    BinInfoRow(color = Color(0xFF0077B6), title = "AZUL", description = "Papel y cartón")
                    BinInfoRow(color = Color(0xFF2D6A4F), title = "VERDE", description = "Vidrio (envases)")
                    BinInfoRow(color = Color(0xFF6D4C41), title = "MARRÓN", description = "Residuos orgánicos")
                    BinInfoRow(color = Color.Gray, title = "GRIS", description = "Resto / No reciclable")
                }

                Spacer(modifier = Modifier.height(24.dp))

                // Pasos para reciclar
                InfoSection(title = "¿CÓMO SEPARAR?") {
                    InfoStep(number = "1", title = "Identifica", description = "Reconoce el material del objeto.")
                    InfoStep(number = "2", title = "Limpia", description = "Quita restos de comida o líquidos.")
                    InfoStep(number = "3", title = "Deposita", description = "Busca el color del contenedor indicado.")
                    InfoStep(number = "4", title = "Impacta", description = "¡Estás ayudando al planeta!")
                }

                Spacer(modifier = Modifier.height(24.dp))

                // Nueva Sección: Mini-Lecciones
                InfoSection(title = stringResource(R.string.info_mini_lessons_title)) {
                    LessonCard(
                        icon = Icons.Default.AutoAwesome,
                        title = stringResource(R.string.lesson_clean_title),
                        description = stringResource(R.string.lesson_clean_desc)
                    )
                }

                Spacer(modifier = Modifier.height(24.dp))

                // Nueva Sección: Materiales Prohibidos
                InfoSection(title = stringResource(R.string.info_prohibited_title)) {
                    Text(
                        text = stringResource(R.string.info_prohibited_desc),
                        style = typography.bodyMedium,
                        color = colorScheme.onSurface.copy(alpha = 0.6f),
                        modifier = Modifier.padding(bottom = 12.dp)
                    )
                    ProhibitedItem(text = "Espejos y cristales de ventanas")
                    ProhibitedItem(text = "Servilletas o cartón con grasa/comida")
                    ProhibitedItem(text = "Cerámica y loza (tazas, platos)")
                    ProhibitedItem(text = "Papel plastificado o encerado")
                    ProhibitedItem(text = "Restos sanitarios (pañales, mascarillas)")
                }

                Spacer(modifier = Modifier.height(24.dp))

                // Footer Impacto
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(24.dp),
                    color = colorScheme.secondary.copy(alpha = 0.1f)
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "🌿 TU ACCIÓN CUENTA",
                            style = typography.titleMedium,
                            color = colorScheme.primary,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Reciclar reduce la contaminación y ahorra recursos naturales para el futuro.",
                            textAlign = TextAlign.Center,
                            style = typography.bodyMedium,
                            color = Color.DarkGray
                        )
                    }
                }
                
                Spacer(modifier = Modifier.height(32.dp))
            }
        }
    }
}

@Composable
fun LessonCard(icon: ImageVector, title: String, description: String) {
    Surface(
        color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.3f),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                Spacer(modifier = Modifier.width(8.dp))
                Text(text = title, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyLarge)
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(text = description, style = MaterialTheme.typography.bodyMedium)
        }
    }
}

@Composable
fun ProhibitedItem(text: String) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.padding(vertical = 4.dp)
    ) {
        Icon(
            Icons.Default.Warning,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.error,
            modifier = Modifier.size(16.dp)
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(text = text, style = MaterialTheme.typography.bodyMedium)
    }
}

@Composable
fun InfoSection(title: String, content: @Composable () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(24.dp)) {
            Text(
                text = title,
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.primary,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp
            )
            Spacer(modifier = Modifier.height(16.dp))
            content()
        }
    }
}

@Composable
fun BinInfoRow(color: Color, title: String, description: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(40.dp)
                .background(color, RoundedCornerShape(12.dp))
        )
        Spacer(modifier = Modifier.width(16.dp))
        Column {
            Text(
                text = title,
                style = MaterialTheme.typography.bodyLarge,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = description,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
            )
        }
    }
}

@Composable
fun InfoStep(number: String, title: String, description: String) {
    Row(
        modifier = Modifier.padding(vertical = 10.dp),
        verticalAlignment = Alignment.Top
    ) {
        Surface(
            modifier = Modifier.size(28.dp),
            shape = CircleShape,
            color = MaterialTheme.colorScheme.primary
        ) {
            Box(contentAlignment = Alignment.Center) {
                Text(
                    text = number,
                    style = MaterialTheme.typography.bodySmall,
                    color = Color.White,
                    fontWeight = FontWeight.Bold
                )
            }
        }
        Spacer(modifier = Modifier.width(16.dp))
        Column {
            Text(
                text = title,
                style = MaterialTheme.typography.bodyLarge,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = description,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f)
            )
        }
    }
}
