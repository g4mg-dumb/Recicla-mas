﻿package com.example.recicla

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.MenuBook
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.res.stringResource
import kotlinx.coroutines.launch

/**
 * Pantalla principal de la aplicación de reciclaje.
 */
@Composable
fun MainScreen(
    fact: String,
    tipsEnabled: Boolean,
    onScanClick: () -> Unit,
    onHistoryClick: () -> Unit = {},
    onSearch: (String) -> Unit = {},
    onInfoClick: () -> Unit = {},
    onPointsClick: () -> Unit = {},
    onHowToUseClick: () -> Unit = {},
    onDevelopersClick: () -> Unit = {},
    onSettingsClick: () -> Unit = {}
) {
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    var searchQuery by remember { mutableStateOf("") }
    
    val colorScheme = MaterialTheme.colorScheme
    val typography = MaterialTheme.typography

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet(
                drawerContainerColor = colorScheme.background,
                drawerShape = RoundedCornerShape(topEnd = 16.dp, bottomEnd = 16.dp)
            ) {
                Spacer(modifier = Modifier.height(24.dp))
                
                // Encabezado del Drawer con Logo
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.app_logo),
                        contentDescription = null,
                        modifier = Modifier
                            .size(80.dp)
                            .clip(CircleShape)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "RECICLA+",
                        style = typography.titleLarge,
                        color = colorScheme.primary
                    )
                }

                HorizontalDivider(modifier = Modifier.padding(horizontal = 16.dp))
                
                Spacer(modifier = Modifier.height(16.dp))

                // Items del Menú
                NavigationDrawerItem(
                    label = { Text("Inicio", style = typography.bodyLarge, fontWeight = FontWeight.SemiBold) },
                    selected = false,
                    onClick = { scope.launch { drawerState.close() } },
                    icon = { Icon(Icons.Default.Home, contentDescription = null) },
                    modifier = Modifier.padding(NavigationDrawerItemDefaults.ItemPadding),
                    colors = NavigationDrawerItemDefaults.colors(
                        unselectedTextColor = colorScheme.primary,
                        unselectedIconColor = colorScheme.primary
                    )
                )

                NavigationDrawerItem(
                    label = { Text("Historial de Escaneo", style = typography.bodyLarge, fontWeight = FontWeight.SemiBold) },
                    selected = false,
                    onClick = { 
                        scope.launch { 
                            drawerState.close()
                            onHistoryClick()
                        } 
                    },
                    icon = { Icon(Icons.Default.History, contentDescription = null) },
                    modifier = Modifier.padding(NavigationDrawerItemDefaults.ItemPadding),
                    colors = NavigationDrawerItemDefaults.colors(
                        unselectedTextColor = colorScheme.primary,
                        unselectedIconColor = colorScheme.primary
                    )
                )

                NavigationDrawerItem(
                    label = { Text("Configuración", style = typography.bodyLarge, fontWeight = FontWeight.SemiBold) },
                    selected = false,
                    onClick = { 
                        scope.launch { 
                            drawerState.close()
                            onSettingsClick()
                        } 
                    },
                    icon = { Icon(Icons.Default.Settings, contentDescription = null) },
                    modifier = Modifier.padding(NavigationDrawerItemDefaults.ItemPadding),
                    colors = NavigationDrawerItemDefaults.colors(
                        unselectedTextColor = colorScheme.primary,
                        unselectedIconColor = colorScheme.primary
                    )
                )

                NavigationDrawerItem(
                    label = { Text("Desarrolladores", style = typography.bodyLarge, fontWeight = FontWeight.SemiBold) },
                    selected = false,
                    onClick = { 
                        scope.launch { 
                            drawerState.close()
                            onDevelopersClick()
                        } 
                    },
                    icon = { Icon(Icons.Default.Groups, contentDescription = null) },
                    modifier = Modifier.padding(NavigationDrawerItemDefaults.ItemPadding),
                    colors = NavigationDrawerItemDefaults.colors(
                        unselectedTextColor = colorScheme.primary,
                        unselectedIconColor = colorScheme.primary
                    )
                )

                Spacer(modifier = Modifier.weight(1f))

                HorizontalDivider(modifier = Modifier.padding(horizontal = 16.dp))

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp)
                ) {
                    Text(
                        text = "CONTACTO",
                        style = typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = colorScheme.primary.copy(alpha = 0.6f)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    
                    ContactItem(icon = Icons.Default.Email, text = "reciclamasproyecto@gmail.com")
                    ContactItem(icon = Icons.Default.CameraAlt, text = "IG: reciclamas.app")
                    ContactItem(icon = Icons.Default.PlayArrow, text = "TikTok: @reciclamasproyecto")
                }
            }
        }
    ) {
        Scaffold(
            modifier = Modifier.fillMaxSize(),
            containerColor = colorScheme.background,
            topBar = {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 40.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    IconButton(onClick = { scope.launch { drawerState.open() } }) {
                        Icon(
                            imageVector = Icons.Default.Menu,
                            contentDescription = "Menu",
                            tint = colorScheme.primary,
                            modifier = Modifier.size(32.dp)
                        )
                    }
                }
            }
        ) { innerPadding ->
            Box(modifier = Modifier.fillMaxSize().padding(innerPadding)) {
                // Background Leaf Decorations
                Icon(
                    imageVector = Icons.Default.Eco,
                    contentDescription = null,
                    tint = colorScheme.secondary.copy(alpha = 0.2f),
                    modifier = Modifier
                        .size(120.dp)
                        .align(Alignment.CenterStart)
                        .offset(x = (-40).dp, y = (-150).dp)
                )
                Icon(
                    imageVector = Icons.Default.Spa,
                    contentDescription = null,
                    tint = colorScheme.secondary.copy(alpha = 0.2f),
                    modifier = Modifier
                        .size(150.dp)
                        .align(Alignment.BottomStart)
                        .offset(x = (-50).dp, y = (-250).dp)
                )

                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 24.dp)
                        .verticalScroll(rememberScrollState()),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Spacer(modifier = Modifier.height(20.dp))

                    // Logo and Title Section
                    Image(
                        painter = painterResource(id = R.drawable.app_logo),
                        contentDescription = "Logo Recicla+",
                        modifier = Modifier
                            .size(120.dp)
                            .clip(CircleShape)
                    )
                    Text(
                        text = "RECICLA+",
                        style = typography.headlineLarge,
                        color = colorScheme.primary,
                        modifier = Modifier.padding(top = 8.dp)
                    )
                    Text(
                        text = "Escanea. Aprende. Recicla.\nCuida nuestro planeta 💚",
                        textAlign = TextAlign.Center,
                        style = typography.bodyLarge,
                        color = colorScheme.primary,
                        modifier = Modifier.padding(top = 8.dp)
                    )

                    Spacer(modifier = Modifier.height(32.dp))

                    // Search Bar
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 4.dp),
                        placeholder = { Text(stringResource(R.string.search_placeholder), fontSize = 14.sp) },
                        leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = colorScheme.primary) },
                        trailingIcon = {
                            if (searchQuery.isNotEmpty()) {
                                IconButton(onClick = { 
                                    onSearch(searchQuery)
                                    searchQuery = "" 
                                }) {
                                    Icon(Icons.Default.ArrowForward, contentDescription = "Buscar", tint = colorScheme.primary)
                                }
                            }
                        },
                        singleLine = true,
                        shape = RoundedCornerShape(28.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = colorScheme.primary,
                            unfocusedBorderColor = colorScheme.primary.copy(alpha = 0.3f),
                            focusedContainerColor = colorScheme.surface,
                            unfocusedContainerColor = colorScheme.surface
                        )
                    )

                    Spacer(modifier = Modifier.height(32.dp))

                    // Action Buttons
                    ActionButton(
                        title = "ESCANEAR OBJETO",
                        subtitle = "Toma una foto y descubre cómo reciclarlo",
                        icon = Icons.Default.CameraAlt,
                        backgroundColor = colorScheme.primary,
                        onClick = onScanClick
                    )

                    Spacer(modifier = Modifier.height(20.dp))

                    ActionButton(
                        title = "INFORMACIÓN",
                        subtitle = "Aprende sobre reciclaje y materiales",
                        icon = Icons.AutoMirrored.Filled.MenuBook,
                        backgroundColor = colorScheme.secondary,
                        onClick = onInfoClick
                    )

                    Spacer(modifier = Modifier.height(20.dp))

                    ActionButton(
                        title = "PUNTOS DE ALMACENAJE",
                        subtitle = "Encuentra dónde almacenar para reciclar",
                        icon = Icons.Default.LocationOn,
                        backgroundColor = colorScheme.primary,
                        onClick = onPointsClick
                    )

                    Spacer(modifier = Modifier.height(20.dp))

                    ActionButton(
                        title = "¿CÓMO SE USA?",
                        subtitle = "Consejos para un escaneo perfecto",
                        icon = Icons.Default.Info,
                        backgroundColor = colorScheme.secondary,
                        onClick = onHowToUseClick
                    )

                    Spacer(modifier = Modifier.height(40.dp))
                    
                    HorizontalDivider(
                        modifier = Modifier.padding(horizontal = 32.dp),
                        thickness = 1.dp,
                        color = colorScheme.primary.copy(alpha = 0.1f)
                    )

                    Spacer(modifier = Modifier.height(32.dp))

                    // Footer Section / Did You Know
                    if (tipsEnabled) {
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(min = 100.dp),
                            shape = RoundedCornerShape(24.dp),
                            colors = CardDefaults.cardColors(containerColor = colorScheme.surface)
                        ) {
                            Column(
                                modifier = Modifier.padding(16.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Lightbulb,
                                        contentDescription = null,
                                        tint = colorScheme.primary,
                                        modifier = Modifier.size(20.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = "CONSEJO DEL DÍA",
                                        style = typography.labelLarge,
                                        fontWeight = FontWeight.Bold,
                                        color = colorScheme.primary
                                    )
                                }
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = fact,
                                    style = typography.bodyMedium,
                                    textAlign = TextAlign.Start,
                                    color = colorScheme.onSurface.copy(alpha = 0.8f),
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }
                        }
                    }
                    Spacer(modifier = Modifier.height(32.dp))
                }
            }
        }
    }
}

@Composable
fun ContactItem(icon: ImageVector, text: String) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.padding(vertical = 4.dp)
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(18.dp)
        )
        Spacer(modifier = Modifier.width(12.dp))
        Text(
            text = text,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f)
        )
    }
}

@Composable
fun ActionButton(
    title: String,
    subtitle: String,
    icon: ImageVector,
    backgroundColor: Color,
    onClick: () -> Unit
) {
    Button(
        onClick = onClick,
        modifier = Modifier
            .fillMaxWidth()
            .height(100.dp),
        shape = RoundedCornerShape(24.dp),
        colors = ButtonDefaults.buttonColors(containerColor = backgroundColor),
        contentPadding = PaddingValues(horizontal = 24.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(
                modifier = Modifier.size(56.dp),
                shape = CircleShape,
                color = Color.White
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = backgroundColor,
                        modifier = Modifier.size(28.dp)
                    )
                }
            }
            Spacer(modifier = Modifier.width(16.dp))
            Column {
                Text(
                    text = title,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
                Text(
                    text = subtitle,
                    fontSize = 14.sp,
                    color = Color.White.copy(alpha = 0.8f),
                    lineHeight = 18.sp
                )
            }
        }
    }
}

@Preview(showBackground = true)
@Composable
fun MainScreenPreview() {
    MainScreen(
        fact = "Reciclar una tonelada de papel ahorra 17 árboles.",
        tipsEnabled = true,
        onScanClick = {}
    )
}
