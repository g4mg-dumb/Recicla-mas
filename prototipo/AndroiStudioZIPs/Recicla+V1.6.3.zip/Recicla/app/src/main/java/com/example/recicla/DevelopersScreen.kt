package com.example.recicla

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Eco
import androidx.compose.material.icons.filled.Spa
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DevelopersScreen(onBack: () -> Unit) {
    val colorScheme = MaterialTheme.colorScheme
    val typography = MaterialTheme.typography

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = {
                    Text(
                        text = "Desarrolladores",
                        color = Color.White,
                        style = typography.titleLarge
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Volver",
                            tint = Color.White
                        )
                    }
                },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    containerColor = colorScheme.primary
                )
            )
        },
        containerColor = colorScheme.background
    ) { innerPadding ->
        Box(modifier = Modifier.fillMaxSize().padding(innerPadding)) {
            // Decoraciones de fondo (Hojas sutiles)
            Icon(
                imageVector = Icons.Default.Eco,
                contentDescription = null,
                tint = colorScheme.secondary.copy(alpha = 0.08f),
                modifier = Modifier
                    .size(150.dp)
                    .align(Alignment.TopEnd)
                    .offset(x = 40.dp, y = 100.dp)
            )
            Icon(
                imageVector = Icons.Default.Spa,
                contentDescription = null,
                tint = colorScheme.secondary.copy(alpha = 0.08f),
                modifier = Modifier
                    .size(200.dp)
                    .align(Alignment.BottomStart)
                    .offset(x = (-60).dp, y = 50.dp)
            )

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(24.dp)
                    .verticalScroll(rememberScrollState()),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "EQUIPO DE DESARROLLO",
                    style = typography.titleLarge,
                    color = colorScheme.primary,
                    modifier = Modifier.padding(bottom = 24.dp)
                )

                DeveloperItem("Gabriel Meneses", "Programador & Gerente del proyecto")
                DeveloperItem("Jorge Badani", "Desarrollador & Programador")
                DeveloperItem("Elian Sepúlveda", "Líder diseñador Gráfico & Desarrollador")
                DeveloperItem("Renato Vásquez", "Desarrollador IA & Programador")
                DeveloperItem("Benjamín Suaréz", "Programador")
                DeveloperItem("Daniel Vega", "Programador")
                DeveloperItem("Arlette Viveros", "Programador")
                DeveloperItem("Francisca Calle", "Diseñador Gráfico")
                DeveloperItem("Alejandra Mamani", "Diseñador Gráfico")

                Spacer(modifier = Modifier.height(32.dp))

                Text(
                    text = "Proyecto desarrollado por estudiantes de Programación",
                    style = typography.bodyMedium,
                    textAlign = TextAlign.Center,
                    color = Color.Gray
                )
                Text(
                    text = "4°E",
                    style = typography.titleLarge,
                    color = colorScheme.primary,
                    modifier = Modifier.padding(top = 4.dp)
                )
            }
        }
    }
}

@Composable
fun DeveloperItem(name: String, role: String) {
    val colorScheme = MaterialTheme.colorScheme
    val typography = MaterialTheme.typography

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = name,
            style = typography.bodyLarge.copy(fontWeight = FontWeight.Bold),
            color = MaterialTheme.colorScheme.onBackground
        )
        Text(
            text = role,
            style = typography.bodyMedium,
            color = colorScheme.primary
        )
        HorizontalDivider(
            modifier = Modifier.padding(top = 8.dp).width(150.dp),
            thickness = 1.dp,
            color = Color.LightGray.copy(alpha = 0.5f)
        )
    }
}
