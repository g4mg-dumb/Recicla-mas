package com.example.recicla

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

import com.example.recicla.ui.theme.DarkGreen

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MaterialDetailScreen(
    info: RecyclingInfo,
    onBack: () -> Unit
) {
    val colorScheme = MaterialTheme.colorScheme
    val typography = MaterialTheme.typography
    
    // Detectamos si el color es el amarillo para aplicar lógica de contraste
    val isYellow = info.containerColor == Color(0xFFFFD60A)
    
    // Tono "Oro/Mostaza" para textos e iconos sobre fondo claro (Menos chillón)
    val contrastColor = if (isYellow) Color(0xFFBC8E00) else info.containerColor
    
    // Un amarillo más suave y pastel para los fondos grandes, para que no sea chillón
    val softBackgroundColor = if (isYellow) Color(0xFFFFF9C4) else info.containerColor.copy(alpha = 0.1f)
    
    // Color de texto para la tarjeta de contenedor (oscuro si el fondo es amarillo)
    val cardContentColor = if (isYellow) DarkGreen else Color.White

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = {
                    Text(
                        text = "GUÍA EDUCATIVA",
                        color = Color.White,
                        style = typography.titleLarge
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = null, tint = Color.White)
                    }
                },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    containerColor = info.containerColor
                )
            )
        },
        containerColor = colorScheme.background
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Encabezado Visual
            Surface(
                modifier = Modifier.size(160.dp),
                shape = CircleShape,
                color = softBackgroundColor
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = getIconForMaterial(info.objectName),
                        contentDescription = null,
                        tint = contrastColor,
                        modifier = Modifier.size(80.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            Text(
                text = info.objectName.uppercase(),
                style = typography.displaySmall, // Mucho más grande y llamativo
                color = contrastColor,
                fontWeight = FontWeight.Black,
                letterSpacing = 2.sp
            )

            Text(
                text = "Manual de Reciclaje",
                style = typography.titleMedium,
                color = colorScheme.onSurface.copy(alpha = 0.5f),
                fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(32.dp))

            // Tarjeta de Contenedor
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(
                    containerColor = if (isYellow) Color(0xFFFFE082) else info.containerColor.copy(alpha = 0.95f),
                    contentColor = cardContentColor
                )
            ) {
                Row(
                    modifier = Modifier.padding(24.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Delete, 
                        contentDescription = null, 
                        tint = cardContentColor, 
                        modifier = Modifier.size(32.dp)
                    )
                    Spacer(modifier = Modifier.width(16.dp))
                    Column {
                        Text(
                            text = "DEPOSITAR EN:", 
                            style = typography.labelLarge, 
                            color = cardContentColor.copy(alpha = 0.8f), 
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = info.containerName, 
                            style = typography.headlineSmall, 
                            color = cardContentColor, 
                            fontWeight = FontWeight.ExtraBold
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Secciones de Información
            DetailSection(
                title = "¿CÓMO RECICLAR?",
                icon = Icons.Default.Lightbulb,
                color = contrastColor,
                content = info.instructions
            )

            Spacer(modifier = Modifier.height(16.dp))

            DetailSection(
                title = "¿SABÍAS QUE?",
                icon = Icons.Default.AutoAwesome,
                color = contrastColor,
                content = info.didYouKnow
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Sección de Impacto (Estatica pero informativa)
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text(
                        text = "TU IMPACTO",
                        style = typography.titleMedium, // Más llamativo
                        color = contrastColor,
                        fontWeight = FontWeight.Black
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "Al reciclar ${info.objectName.lowercase()}, evitas que este material termine en vertederos y ayudas a reducir la extracción de recursos naturales de nuestro planeta.",
                        style = typography.bodyLarge, // Texto más legible
                        color = colorScheme.onSurface
                    )
                }
            }

            Spacer(modifier = Modifier.height(40.dp))

            Button(
                onClick = onBack,
                modifier = Modifier.fillMaxWidth().height(56.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (isYellow) Color(0xFFFFB300) else info.containerColor,
                    contentColor = if (isYellow) DarkGreen else Color.White
                ),
                shape = RoundedCornerShape(28.dp)
            ) {
                Text("ENTENDIDO", fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun DetailSection(title: String, icon: ImageVector, color: Color, content: String) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        color = MaterialTheme.colorScheme.surface,
        border = androidx.compose.foundation.BorderStroke(2.dp, color.copy(alpha = 0.3f)) // Borde más grueso
    ) {
        Column(modifier = Modifier.padding(24.dp)) { // Más padding
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(icon, contentDescription = null, tint = color, modifier = Modifier.size(24.dp))
                Spacer(modifier = Modifier.width(12.dp))
                Text(
                    text = title, 
                    style = MaterialTheme.typography.titleMedium, // Título más grande
                    color = color, 
                    fontWeight = FontWeight.Black
                )
            }
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                text = content, 
                style = MaterialTheme.typography.bodyLarge, // Cuerpo más grande
                color = MaterialTheme.colorScheme.onSurface
            )
        }
    }
}

private fun getIconForMaterial(name: String): ImageVector {
    return when {
        name.contains("Plástico", true) -> Icons.Default.Inventory
        name.contains("Papel", true) -> Icons.Default.Description
        name.contains("Cartón", true) -> Icons.Default.AllInbox
        name.contains("Vidrio", true) -> Icons.Default.LocalBar
        name.contains("Metal", true) -> Icons.Default.Kitchen
        name.contains("Orgánico", true) -> Icons.Default.Eco
        else -> Icons.Default.Category
    }
}
