package com.example.recicla

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Modelo de datos para un registro del historial.
 */
data class ScanRecord(
    val id: Int = 0,
    val material: String,
    val container: String,
    val date: String,
    val note: String = ""
)

/**
 * Gestor de la base de datos SQLite para el historial de escaneos.
 */
class DatabaseHelper(context: Context) : SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {

    companion object {
        private const val DATABASE_NAME = "recicla_history.db"
        private const val DATABASE_VERSION = 1
        
        private const val TABLE_HISTORY = "history"
        private const val COLUMN_ID = "id"
        private const val COLUMN_MATERIAL = "material"
        private const val COLUMN_CONTAINER = "container"
        private const val COLUMN_DATE = "date"
        private const val COLUMN_NOTE = "note"
    }

    override fun onCreate(db: SQLiteDatabase) {
        val createTable = ("CREATE TABLE " + TABLE_HISTORY + "("
                + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + COLUMN_MATERIAL + " TEXT,"
                + COLUMN_CONTAINER + " TEXT,"
                + COLUMN_DATE + " TEXT,"
                + COLUMN_NOTE + " TEXT" + ")")
        db.execSQL(createTable)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS $TABLE_HISTORY")
        onCreate(db)
    }

    /**
     * Inserta un nuevo registro de escaneo.
     */
    fun insertRecord(material: String, container: String): Long {
        val db = this.writableDatabase
        val dateFormat = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault())
        val date = dateFormat.format(Date())
        
        val values = ContentValues().apply {
            put(COLUMN_MATERIAL, material)
            put(COLUMN_CONTAINER, container)
            put(COLUMN_DATE, date)
            put(COLUMN_NOTE, "")
        }
        
        val result = db.insert(TABLE_HISTORY, null, values)
        db.close()
        return result
    }

    /**
     * Obtiene todos los registros del historial, del más reciente al más antiguo.
     */
    fun getAllRecords(): List<ScanRecord> {
        val recordList = mutableListOf<ScanRecord>()
        val selectQuery = "SELECT * FROM $TABLE_HISTORY ORDER BY $COLUMN_ID DESC"
        val db = this.readableDatabase
        val cursor = db.rawQuery(selectQuery, null)

        if (cursor.moveToFirst()) {
            do {
                val record = ScanRecord(
                    id = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_ID)),
                    material = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_MATERIAL)),
                    container = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_CONTAINER)),
                    date = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_DATE)),
                    note = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_NOTE))
                )
                recordList.add(record)
            } while (cursor.moveToNext())
        }
        cursor.close()
        db.close()
        return recordList
    }

    /**
     * Actualiza la nota de un registro específico.
     */
    fun updateNote(id: Int, newNote: String): Int {
        val db = this.writableDatabase
        val values = ContentValues().apply {
            put(COLUMN_NOTE, newNote)
        }
        val result = db.update(TABLE_HISTORY, values, "$COLUMN_ID = ?", arrayOf(id.toString()))
        db.close()
        return result
    }

    /**
     * Elimina un registro del historial.
     */
    fun deleteRecord(id: Int): Int {
        val db = this.writableDatabase
        val result = db.delete(TABLE_HISTORY, "$COLUMN_ID = ?", arrayOf(id.toString()))
        db.close()
        return result
    }
}
