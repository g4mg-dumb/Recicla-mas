# Plan de Implementación: Rediseño de la Pantalla "¿Cómo se usa?"

Este plan detalla las mejoras visuales para la pantalla de guía de uso, buscando una estética más moderna, limpia y coherente con el resto de la aplicación.

## User Review Required

> [!TIP]
> **Mejora Visual:** Cambiaremos el diseño de las tarjetas de instrucción por uno más dinámico, utilizando indicadores numéricos más grandes y un estilo de "tarjeta elevada" que destaque mejor sobre el fondo decorativo.

## Proposed Changes

### Rediseño de UI en HowToUseScreen

#### [MODIFY] [HowToUseScreen.kt](file:///C:/Users/gabo/Desktop/versionesR+/Recicla+V1.3/Recicla/app/src/main/java/com/example/recicla/HowToUseScreen.kt)
- **Cabecera Dinámica**: Mejorar el diseño del título principal con una tipografía más pesada y un contenedor con leve desenfoque o transparencia.
- **Indicadores de Pasos**: Sustituir el diseño simple de `InstructionCard` por uno que use burbujas numéricas de colores (estilo similar a los pasos de `InfoScreen`).
- **Nuevas Tarjetas**: Implementar bordes suaves, sombras sutiles y mejores contrastes para que el texto sea más legible.
- **Sección de Consejos**: Rediseñar la caja de consejos finales para que parezca una "burbuja de sabiduría" más atractiva.
- **Botón de Acción**: Refinar el botón "ENTENDIDO" para que use el estilo de botones de la pantalla principal (bordes muy redondeados y sombra).

## Verification Plan

### Manual Verification
1. **Estética**: Abrir la pantalla desde el menú o al inicio y verificar que las tarjetas se vean "premium" y modernas.
2. **Legibilidad**: Confirmar que el texto se lee perfectamente sobre el fondo de hojas.
3. **Funcionalidad**: Asegurarse de que el botón inferior siga llevando correctamente al menú principal.
