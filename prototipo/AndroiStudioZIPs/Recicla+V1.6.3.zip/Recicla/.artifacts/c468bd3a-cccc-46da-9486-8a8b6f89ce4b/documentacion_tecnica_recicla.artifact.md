# Documentación Técnica de Recicla+

Este documento proporciona una visión general técnica de la aplicación **Recicla+**, diseñada para ayudar a los desarrolladores a comprender la arquitectura, las tecnologías y la estructura del proyecto.

---

## 🚀 Tecnologías Principales

- **Lenguaje**: [Kotlin](https://kotlinlang.org/) (100%).
- **UI Framework**: [Jetpack Compose](https://developer.android.com/compose) con **Material 3**.
- **Arquitectura**: Patrón declarativo basado en estados y navegación por componentes.
- **Inteligencia Artificial**: [TensorFlow Lite](https://www.tensorflow.org/lite) para la clasificación de objetos mediante cámara.
- **Base de Datos**: [SQLite](https://sqlite.org/) (vía `SQLiteOpenHelper`) para el historial de escaneos.
- **Navegación**: Jetpack Compose Navigation.
- **Carga de Imágenes**: Coil para la renderización eficiente de imágenes.

---

## 📂 Estructura del Proyecto

### `app/src/main/java/com/example/recicla`
Este es el corazón de la programación. Aquí se encuentran todas las clases de lógica y vista:

| Archivo / Carpeta | Función |
| :--- | :--- |
| **`MainActivity.kt`** | **Punto de entrada.** Gestiona la navegación principal (`NavHost`), los permisos de cámara y los estados globales (tema, tutorial). |
| **`MainScreen.kt`** | Pantalla principal. Contiene el menú de navegación (Drawer) y los accesos rápidos. |
| **`ImageClassifierHelper.kt`** | **Cerebro de la IA.** Carga el modelo de TensorFlow y procesa los bitmaps de la cámara para identificar materiales. |
| **`DatabaseHelper.kt`** | Gestiona la persistencia. Crea la tabla de historial y ofrece métodos CRUD (Crear, Leer, Actualizar, Borrar). |
| **`ui/theme/`** | Define la identidad visual (colores, tipografía y el objeto `ReciclaTheme`). |

### `app/src/main/res`
Contiene los recursos visuales y de configuración:

- **`drawable/`**: Logos, iconos y fondos decorativos.
- **`values/`**:
    - `strings.xml`: Todos los textos de la app (fundamental para traducción).
    - `themes.xml`: Configuración del splash screen y estilos base.
- **`xml/`**: Reglas de backup y configuración del sistema.

### `app/src/main/assets` (Normalmente presente)
Aquí se almacena el modelo `.tflite` que utiliza `ImageClassifierHelper` para reconocer el plástico, papel, etc.

---

## 🛠️ Flujo de Trabajo Clave

### 1. Detección de Objetos
1. El usuario presiona "Escanear" en `MainScreen`.
2. `MainActivity` solicita permisos y abre la cámara.
3. Al capturar la foto, se envía a `ImageClassifierHelper`.
4. El resultado (ej: "Plástico") se usa para buscar información en `getRecyclingInfo`.
5. Se guarda automáticamente en la base de datos mediante `DatabaseHelper`.
6. Se navega a `ResultScreen` para mostrar la información.

### 2. Navegación
La app utiliza un `NavController`. Cada pantalla es una función `@Composable` independiente, lo que facilita mucho la creación de nuevas secciones sin tocar el flujo de otras.

---

## 💡 Consejos para Nuevos Desarrolladores

> [!TIP]
> **Edición de UI:** Si necesitas cambiar un color o texto, busca primero en `ui/theme/Color.kt` o `res/values/strings.xml`. No escribas valores a mano en los componentes.

> [!IMPORTANT]
> **Base de Datos:** Si cambias la estructura de la tabla en `DatabaseHelper`, recuerda aumentar la `DATABASE_VERSION` para que la app se actualice correctamente en los teléfonos de los usuarios.

> [!CAUTION]
> **Rendimiento:** La IA consume recursos. Siempre cierra el clasificador (`classifier.close()`) cuando el componente se destruya, como se hace en el `DisposableEffect` de `MainActivity`.

---

Documento preparado por el Asistente de Desarrollo de Android Studio para el equipo de **Recicla+**.
