# Tareas de Implementación: Ajustes de Identidad y Flujo

- [x] Modificar `AndroidManifest.xml` para usar el logo redondo (`app_logo`) como icono principal.
- [x] Implementar la persistencia de `show_tutorial` en `MainActivity.kt`.
- [x] Configurar navegación dinámica en `MainActivity.kt` basada en la preferencia del tutorial.
- [x] Añadir interruptor en `SettingsScreen.kt` para controlar el tutorial de inicio.
- [x] Añadir botón de navegación en `HowToUseScreen.kt` para ir al inicio.
- [x] Renombrar "Puntos de Reciclaje" a "Puntos de Almacenaje" en `MainScreen.kt`.
- [x] Actualizar títulos y descripciones en `PointsScreen.kt`.
- [x] Corregir lógica de navegación en el botón "Entendido" del tutorial.
- [x] Rediseñar visualmente la pantalla `HowToUseScreen.kt`.
- [x] Verificar cambios y funcionamiento general.
