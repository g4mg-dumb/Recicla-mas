# Tareas: Implementación de Configuración y Modo Oscuro

- `[x]` Preparar el sistema de temas en `Theme.kt`
- `[x]` Crear la pantalla `SettingsScreen.kt`
- `[x]` Configurar la navegación y el estado global en `MainActivity.kt`
- `[x]` Implementar persistencia básica del tema (SharedPreferences)
- `[x]` Adaptar pantallas existentes (`Main`, `Info`, `Result`) al Modo Oscuro
- `[x]` Verificar el funcionamiento de los cambios
