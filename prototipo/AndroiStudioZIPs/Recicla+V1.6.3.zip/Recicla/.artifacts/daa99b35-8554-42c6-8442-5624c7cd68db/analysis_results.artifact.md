# Análisis de la Gestión de Datos en Recicla+

Tras revisar el código fuente, aquí tienes el desglose de cómo la aplicación maneja la información.

## ¿Dónde está la "Base de Datos"?

Actualmente, **no existe una base de datos formal** (como SQLite o Room). La información sobre el reciclaje está gestionada mediante **Lógica Hardcoded** (datos escritos directamente en el código).

### El Corazón de los Datos: `getRecyclingInfo`
Toda la "inteligencia" de qué hacer con un objeto está en la función [getRecyclingInfo](file:///C:/Users/gabo/Desktop/Recicla+V1.3/Recicla/app/src/main/java/com/example/recicla/MainActivity.kt#L182-L245) dentro de `MainActivity.kt`.

Esta función usa una estructura `when` que mapea la etiqueta detectada por la IA (ej: "plastico") con un objeto `RecyclingInfo` que contiene:
- Nombre del objeto.
- Tipo de residuo.
- Color del contenedor.
- Instrucciones específicas.

### Etiquetas de la IA
Las categorías que la app puede reconocer vienen dictadas por el archivo [labels.txt](file:///C:/Users/gabo/Desktop/Recicla+V1.3/Recicla/app/src/main/assets/labels.txt) en la carpeta de assets.

## Evaluación de Racionalidad

¿Es racional esta estructura? **Depende del alcance actual del proyecto.**

### Puntos a Favor (Por qué es racional ahora):
1.  **Simplicidad**: Para un proyecto escolar o un MVP (Producto Mínimo Viable), no añade complejidad innecesaria.
2.  **Velocidad**: El acceso a los datos es instantáneo, no hay que esperar a que una base de datos se abra o una red responda.
3.  **Peso de la App**: Al no usar librerías de base de datos pesadas, la app se mantiene ligera.

### Limitaciones (Por qué podría dejar de ser racional):
1.  **Escalabilidad**: Si quieres añadir 100 tipos de objetos, el archivo `MainActivity.kt` se volvería gigante y difícil de leer.
2.  **Actualizaciones**: Si el liceo cambia el color de un contenedor, tienes que **recompilar y reinstalar la app**. No puedes cambiar los datos "en el aire".
3.  **Falta de Memoria**: La app no recuerda lo que has escaneado antes porque no guarda nada en el disco.

## Recomendación de Evolución

Si quieres profesionalizar la gestión de datos, el camino racional sería:

1.  **Nivel Intermedio (JSON)**: Mover la información a un archivo `recycling_data.json` en assets. Así separas los *datos* del *código*.
2.  **Nivel Avanzado (Room)**: Si quieres guardar un **Historial de Escaneos** del usuario, necesitarás usar la librería [Room](https://developer.android.com/training/data-storage/room) de Android para persistencia local.
3.  **Nivel Experto (Firebase)**: Si quieres actualizar los consejos o colores de contenedores sin actualizar la app, podrías usar [Firebase Remote Config](https://firebase.google.com/docs/remote-config) o Firestore.

> [!TIP]
> Para el estado actual del proyecto, la estructura es **racional y funcional**. Sin embargo, si planeas añadir el "Historial" que mencionamos en el plan de configuración, necesitaremos implementar una pequeña base de datos local.
