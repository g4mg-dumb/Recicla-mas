# Diseño de Base de Datos para Recicla+

Aunque tu app actualmente usa datos estáticos, si quisieras migrar a una base de datos relacional (como MySQL), aquí tienes cómo deberías estructurarla para que sea eficiente y escalable.

## Diagrama de Entidad-Relación (ERD)

Este diagrama muestra cómo se relacionan las tablas para evitar repetir información (normalización).

```mermaid
erDiagram
    CONTENEDOR ||--o{ TIPO_RESIDUO : "se deposita en"
    TIPO_RESIDUO ||--o{ MATERIAL : "clasifica a"
    MATERIAL ||--o{ HISTORIAL : "registra"

    CONTENEDOR {
        int id PK
        string nombre "Ej: Amarillo, Azul"
        string color_hex "Ej: #FFD60A"
    }

    TIPO_RESIDUO {
        int id PK
        string nombre "Ej: Plásticos y latas"
        text instrucciones "Pasos para reciclar"
        int contenedor_id FK
    }

    MATERIAL {
        int id PK
        string etiqueta_ia "Ej: plastico, papel (Labels)"
        string nombre_visible "Ej: Botella de plástico"
        int tipo_residuo_id FK
    }

    HISTORIAL {
        int id PK
        int material_id FK
        datetime fecha_escaneo
        string imagen_path "Ruta a la foto capturada"
    }
```

## Estructura de Tablas (SQL)

Si quisieras crear esto en MySQL Workbench, este sería el código SQL base:

```sql
-- 1. Tabla de Contenedores
CREATE TABLE contenedores (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(50) NOT NULL,
    color_hex VARCHAR(7) NOT NULL
);

-- 2. Tabla de Tipos de Residuo
CREATE TABLE tipos_residuo (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    instrucciones TEXT,
    contenedor_id INT,
    FOREIGN KEY (contenedor_id) REFERENCES contenedores(id)
);

-- 3. Tabla de Materiales (Lo que reconoce la IA)
CREATE TABLE materiales (
    id INT AUTO_INCREMENT PRIMARY KEY,
    etiqueta_ia VARCHAR(50) UNIQUE NOT NULL,
    nombre_visible VARCHAR(100),
    tipo_residuo_id INT,
    FOREIGN KEY (tipo_residuo_id) REFERENCES tipos_residuo(id)
);

-- 4. Tabla de Historial (Para la mejora de la app)
CREATE TABLE historial_escaneos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    material_id INT,
    fecha DATETIME DEFAULT CURRENT_TIMESTAMP,
    imagen_url VARCHAR(255),
    FOREIGN KEY (material_id) REFERENCES materiales(id)
);
```

## ¿Por qué hacerlo así?

1.  **Evitas duplicidad**: Si el liceo decide cambiar las instrucciones del contenedor Azul, solo lo cambias en **un lugar** (`tipos_residuo`) y automáticamente todos los materiales (papel, cartón, revistas) mostrarán la nueva información.
2.  **Escalabilidad**: Puedes añadir 50 tipos de "Materiales" nuevos simplemente insertando filas en la tabla, sin tocar una sola línea de código en Java/Kotlin.
3.  **Historial**: La tabla `historial_escaneos` te permite saber qué es lo que más reciclan los alumnos, lo cual es oro puro para las estadísticas del proyecto.

> [!IMPORTANT]
> En Android, para bases de datos locales se usa **SQLite** (vía la librería Room), que es casi idéntico a MySQL en sintaxis. Si algún día decides usar un servidor en la nube, entonces sí usarías MySQL o PostgreSQL.
