# Walkthrough: Pantalla de Configuración y Modo Oscuro

¡Misión cumplida! He implementado la pantalla de configuración y el sistema de temas (Modo Oscuro/Claro) para **Recicla+**.

## Cambios Principales

### 1. Nueva Pantalla de Configuración
He creado [SettingsScreen.kt](file:///C:/Users/gabo/Desktop/Recicla+V1.3/Recicla/app/src/main/java/com/example/recicla/SettingsScreen.kt) que incluye:
- **Selector de Tema**: Permite elegir entre Claro, Oscuro o el predeterminado del sistema.
- **Limpiar Caché**: Una opción útil para borrar las fotos temporales que la app guarda al escanear, liberando espacio en el teléfono.
- **Información de la App**: Muestra la versión actual y detalles del proyecto.

### 2. Sistema de Temas Dinámico
- He modificado [Theme.kt](file:///C:/Users/gabo/Desktop/Recicla+V1.3/Recicla/app/src/main/java/com/example/recicla/ui/theme/Theme.kt) para soportar el cambio manual de tema.
- Se ha mejorado la paleta de colores para que el **Modo Oscuro** sea elegante y legible, manteniendo la identidad visual verde del proyecto.

### 3. Persistencia de Datos
- En [MainActivity.kt](file:///C:/Users/gabo/Desktop/Recicla+V1.3/Recicla/app/src/main/java/com/example/recicla/MainActivity.kt), he implementado el uso de `SharedPreferences`. Esto significa que **la app recordará tu elección de tema** incluso después de cerrarla y volverla a abrir.

### 4. Adaptación Visual Global
Para asegurar que todo se vea perfecto en modo oscuro, he actualizado las siguientes pantallas:
- [MainScreen.kt](file:///C:/Users/gabo/Desktop/Recicla+V1.3/Recicla/app/src/main/java/com/example/recicla/MainScreen.kt)
- [InfoScreen.kt](file:///C:/Users/gabo/Desktop/Recicla+V1.3/Recicla/app/src/main/java/com/example/recicla/InfoScreen.kt)
- [ResultScreen.kt](file:///C:/Users/gabo/Desktop/Recicla+V1.3/Recicla/app/src/main/java/com/example/recicla/ResultScreen.kt)

> [!TIP]
> Ahora puedes ir al menú lateral, entrar en **Configuración** y probar el cambio a **Modo Oscuro**. ¡Se ve genial!

## Verificación Realizada
- [x] Navegación desde el Drawer a Configuración.
- [x] Cambio de tema en tiempo real en todas las pantallas.
- [x] Persistencia del tema al reiniciar la app.
- [x] Funcionalidad del botón "Limpiar caché".
