# Plan de Mejora y Creación del Menú de Configuración

Este plan detalla ideas para mejorar la aplicación **Recicla+** y la implementación del menú de configuración que actualmente es un marcador de posición.

## Ideas para mejorar la App

Basado en la funcionalidad actual de Recicla+, aquí tienes algunas ideas para llevarla al siguiente nivel:

1.  **Modo Oscuro/Claro**: Una opción fundamental para que el usuario elija su preferencia visual.
2.  **Historial de Escaneos**: Una sección donde los alumnos puedan ver qué objetos han escaneado anteriormente y qué puntaje o información obtuvieron.
3.  **Mapa de Puntos de Reciclaje**: Integración con un mapa para mostrar dónde están los contenedores (puntos limpios) dentro del liceo o la ciudad.
4.  **Gamificación (Logros)**: Un sistema de medallas (ej: "Reciclador Novato", "Héroe del Planeta") para incentivar el uso de la app y el reciclaje real.
5.  **Consejo del Día**: Un banner en la pantalla principal con datos curiosos o consejos útiles sobre el cuidado del medio ambiente.
6.  **Accesibilidad**: Ajustes de tamaño de fuente y alto contraste para que todos los alumnos puedan usar la app sin problemas.

## Propuesta de Implementación: Menú de Configuración

Como primer paso, implementaremos la pantalla de **Configuración** con opciones reales.

### Cambios Propuestos

#### [NEW] [SettingsScreen.kt](file:///C:/Users/gabo/Desktop/Recicla+V1.3/Recicla/app/src/main/java/com/example/recicla/SettingsScreen.kt)
Crearemos una nueva pantalla que incluya:
- Selector de Tema (Claro / Oscuro / Sistema).
- Interruptor para Notificaciones (Simulado por ahora).
- Sección de Información de la App (Versión).
- Enlaces a redes sociales o contacto (reutilizando la lógica del Drawer).

#### [MODIFY] [MainActivity.kt](file:///C:/Users/gabo/Desktop/Recicla+V1.3/Recicla/app/src/main/java/com/example/recicla/MainActivity.kt)
- Añadir la ruta `settings` al `NavHost`.
- Gestionar el estado del tema (Claro/Oscuro) para que persista durante la sesión.
- Conectar el `onSettingsClick` del `MainScreen` con la navegación a la nueva pantalla.

#### [MODIFY] [Theme.kt](file:///C:/Users/gabo/Desktop/Recicla+V1.3/Recicla/app/src/main/java/com/example/recicla/ui/theme/Theme.kt)
- Ajustar el Composable `ReciclaTheme` para aceptar el estado del tema manual si se selecciona en configuración.

## Plan de Verificación

### Pruebas Manuales
- Navegar desde el menú lateral a "Configuración".
- Cambiar entre modo claro y oscuro y verificar que la UI se actualiza inmediatamente.
- Verificar que el botón de retroceso vuelve correctamente a la pantalla principal.
- Comprobar que la estética de la nueva pantalla es coherente con el resto de la app (uso de hojas, verdes, etc.).
