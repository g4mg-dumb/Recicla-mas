# Visión Arquitectónica: Conexión WordPress + Recicla+

Este documento presenta el diseño técnico para centralizar la gestión de datos de reciclaje y puntos limpios mediante un backend en WordPress, permitiendo actualizaciones en tiempo real sin modificar el código de la aplicación.

## 1. Diagrama de Flujo de Datos

Este diagrama muestra cómo la información viaja desde que un profesor o administrador la edita en la web hasta que aparece en el teléfono del alumno.

```mermaid
graph TD
    subgraph "Administración (WordPress)"
        A[Escritorio de WordPress] -->|Edita Punto Limpio| B[(Base de Datos MySQL)]
        B --> C{WordPress REST API}
    end

    subgraph "Nube / Internet"
        C -->|Envía JSON| D[Protocolo HTTPS]
    end

    subgraph "Usuario Final (App Android)"
        D -->|Recibe datos| E[Librería Retrofit]
        E -->|Muestra en Pantalla| F[Pantalla de Información]
        E -->|Guarda para uso offline| G[(Caché Local / Room)]
    end
```

## 2. El "Puente": Ejemplo de JSON

Cuando la app pregunte a WordPress por las localidades, WordPress responderá con un mensaje estructurado como este. Este es el lenguaje que ambos entienden.

```json
{
  "puntos_limpios": [
    {
      "id": 101,
      "nombre": "Patio Central - Contenedor Amarillo",
      "coordenadas": "-18.478, -70.297",
      "estado": "Disponible",
      "ultima_recoleccion": "2024-05-20"
    },
    {
      "id": 102,
      "nombre": "Entrada Gimnasio - Punto Azul",
      "coordenadas": "-18.479, -70.298",
      "estado": "Lleno",
      "ultima_recoleccion": "2024-05-18"
    }
  ]
}
```

## 3. Beneficios para el Proyecto

> [!IMPORTANT]
> **Autonomía Administrativa**: Los profesores pueden actualizar información de la campaña de reciclaje desde cualquier navegador sin saber programar Android.

- **Eficiencia**: Se reduce el tamaño de la app al no tener que guardar toda la información localmente.
- **Escalabilidad**: Hoy son puntos de reciclaje del liceo, mañana pueden ser puntos de toda la ciudad de Arica.
- **Modernidad**: Sitúa al proyecto al nivel de aplicaciones profesionales como Uber o Rappi, que funcionan bajo este mismo principio de API.

## 4. Requisitos Técnicos para el Equipo

Para implementar esto en la siguiente fase, el equipo de desarrollo deberá aprender:

1.  **WordPress**: Cómo crear "Custom Fields" (campos personalizados) para guardar coordenadas o estados.
2.  **Retrofit + Gson**: Las librerías estándar de Android para hacer peticiones a internet y convertir el JSON en objetos de Kotlin.
3.  **Manejo de Corrutinas**: Para que la app no se "congele" mientras descarga los datos de la web.

---
*Diseño preparado para la presentación a docentes y equipo técnico de Recicla+.*
