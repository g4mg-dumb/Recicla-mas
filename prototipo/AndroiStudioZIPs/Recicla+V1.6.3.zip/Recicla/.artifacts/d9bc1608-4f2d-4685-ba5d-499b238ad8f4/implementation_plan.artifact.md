# Plan de Implementación: Historial de Escaneo con SQLite (CRUD Completo)

Este plan detalla la creación de un sistema de historial de escaneos utilizando **SQLite nativo**, lo que garantiza compatibilidad total con la versión de tu proyecto y proporciona una implementación CRUD robusta para tu presentación.

## User Review Required

> [!IMPORTANT]
> Se utilizará **SQLite** en lugar de Room para evitar conflictos con los procesadores de anotaciones de Kotlin 2.x. Esto es técnicamente igual de válido y demuestra un conocimiento profundo de la arquitectura de Android.

> [!TIP]
> Implementaremos el ciclo CRUD completo:
> - **C**reate: Guardar automáticamente al detectar un objeto.
> - **R**ead: Ver la lista en una nueva pantalla.
> - **U**pdate: Permitir al usuario añadir "Notas personales" a cada registro.
> - **D**elete: Permitir borrar registros individuales.

## Proposed Changes

### [Component Name] Limpieza de Configuración
- Revertir los cambios fallidos de Room/KAPT en `build.gradle.kts` y `libs.versions.toml` para estabilizar el proyecto.

### [Component Name] Base de Datos (SQLite)

#### [NEW] `DatabaseHelper.kt`
- Clase que extiende de `SQLiteOpenHelper`.
- Definición de tabla `historial` (id, material, contenedor, fecha, nota).
- Funciones: `insertRecord()`, `getAllRecords()`, `updateNote()`, `deleteRecord()`.

### [Component Name] Interfaz de Usuario (UI)

#### [MODIFY] [MainScreen.kt](file:///C:/Users/gabo/Desktop/versionesR+/Recicla+V1.3/Recicla/app/src/main/java/com/example/recicla/MainScreen.kt)
- Añadir la opción **"Historial de Escaneo"** en el menú deslizante.

#### [NEW] `HistoryScreen.kt`
- Lista vertical de escaneos pasados.
- Cada elemento mostrará el material, la fecha y la nota (si existe).
- Iconos para editar (Update) y borrar (Delete).

### [Component Name] Lógica de Navegación

#### [MODIFY] [MainActivity.kt](file:///C:/Users/gabo/Desktop/versionesR+/Recicla+V1.3/Recicla/app/src/main/java/com/example/recicla/MainActivity.kt)
- Inicializar el `DatabaseHelper`.
- Guardar el registro en la base de datos cada vez que la IA identifique un material.
- Definir la ruta de navegación `history`.

## Verification Plan

### Manual Verification
1.  Realizar un escaneo de prueba.
2.  Navegar al Historial desde el menú lateral.
3.  Verificar que el registro aparece con la fecha actual.
4.  Editar la nota del registro y verificar que se guarda.
5.  Borrar el registro y confirmar que desaparece de la lista.
