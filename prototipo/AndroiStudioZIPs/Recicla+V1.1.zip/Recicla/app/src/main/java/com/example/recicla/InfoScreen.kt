package com.example.recicla

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.recicla.R

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun InfoScreen(onBack: () -> Unit) {
    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = {
                    Text(
                        text = "Información",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 20.sp
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Volver",
                            tint = Color.White
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFF2E6430)
                )
            )
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Fondo con hojas
            Image(
                painter = painterResource(id = R.drawable.info_bg),
                contentDescription = null,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.FillBounds
            )

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Bienvenida
                Image(
                    painter = painterResource(id = R.drawable.info_welcome),
                    contentDescription = "Bienvenido a Recicla+",
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color.White),
                    contentScale = ContentScale.FillWidth
                )

                Spacer(modifier = Modifier.height(16.dp))

                // ¿Qué es Recicla+?
                InfoBox {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Image(
                            painter = painterResource(id = R.drawable.info_what_is),
                            contentDescription = "¿Qué es Recicla+?",
                            modifier = Modifier.fillMaxWidth(),
                            contentScale = ContentScale.FillWidth
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Colores de Basureros
                InfoBox {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Image(
                            painter = painterResource(id = R.drawable.info_bins_banner),
                            contentDescription = "Colores de Basureros",
                            modifier = Modifier.fillMaxWidth(),
                            contentScale = ContentScale.FillWidth
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Image(
                            painter = painterResource(id = R.drawable.info_bins_grid),
                            contentDescription = "Grid de basureros",
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(8.dp),
                            contentScale = ContentScale.FillWidth
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Sección adicional: Cómo separar (con estilo de texto)
                InfoBox {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "¿CÓMO SEPARAR LOS RESIDUOS?",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF2E6430)
                        )
                        Text(
                            text = "Guía rápida para hacerlo correctamente",
                            fontSize = 17.sp,
                            color = Color.Gray
                        )
                        
                        Spacer(modifier = Modifier.height(14.dp))
                        
                        InfoStep(number = "1", title = "Identifica el residuo", description = "Reconoce si es plástico, papel, vidrio, metal u orgánico.")
                        InfoStep(number = "2", title = "Limpia el envase", description = "Enjuaga restos de comida para evitar contaminación.")
                        InfoStep(number = "3", title = "Separa correctamente", description = "Deposita en el contenedor según su color.")
                        InfoStep(number = "4", title = "Ayuda al planeta", description = "¡Tú haces la diferencia en nuestro liceo!")
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Impacto Ambiental
                InfoBox {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "IMPACTO AMBIENTAL",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF2E6430)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        ImpactRow(text = "Reduce la contaminación local.")
                        ImpactRow(text = "Ahorra recursos naturales.")
                        ImpactRow(text = "Mejora la calidad de vida.")
                        
                        Spacer(modifier = Modifier.height(16.dp))
                        
                        Surface(
                            color = Color(0xFFE8F5E9),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "¡JUNTOS HACEMOS LA DIFERENCIA!\nReciclar es cuidar nuestro futuro.",
                                textAlign = TextAlign.Center,
                                color = Color(0xFF2E6430),
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(12.dp),
                                fontSize = 14.sp
                            )
                        }
                    }
                }
                
                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }
}

@Composable
fun InfoBox(content: @Composable () -> Unit) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .border(2.dp, Color(0xFF2E6430), RoundedCornerShape(8.dp)),
        shape = RoundedCornerShape(8.dp),
        color = Color(0xFFF9F9F0).copy(alpha = 0.9f),
        content = content
    )
}

@Composable
fun InfoStep(number: String, title: String, description: String) {
    Row(modifier = Modifier.padding(vertical = 4.dp)) {
        Surface(
            modifier = Modifier.size(22.dp),
            shape = RoundedCornerShape(10.dp),
            color = Color(0xFF2E6430)
        ) {
            Box(contentAlignment = Alignment.Center) {
                Text(text = number, fontSize = 12.sp, color = Color.White, fontWeight = FontWeight.Bold)
            }
        }
        Spacer(modifier = Modifier.width(8.dp))
        Column {
            Text(text = title, fontWeight = FontWeight.Bold, fontSize = 17.sp, color = Color(0xFF2E6430))
            Text(text = description, fontSize = 15.sp, color = Color.DarkGray)
        }
    }
}

@Composable
fun ImpactRow(text: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 2.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text("🌿", modifier = Modifier.padding(end = 8.dp))
        Text(text = text, fontSize = 15.sp, color = Color.Black)
    }
}
