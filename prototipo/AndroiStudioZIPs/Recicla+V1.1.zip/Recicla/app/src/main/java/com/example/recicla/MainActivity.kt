﻿package com.example.recicla

import android.content.pm.ActivityInfo
import android.graphics.Bitmap
import android.util.Log
import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.recicla.ui.theme.ReciclaTheme
import java.io.File
import java.io.FileOutputStream

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Forzar orientación vertical por código para mayor seguridad
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
        enableEdgeToEdge()
        setContent {
            ReciclaTheme {
                ReciclaApp()
            }
        }
    }
}

@Composable
fun ReciclaApp() {
    val navController = rememberNavController()
    val context = LocalContext.current
    val classifier = remember { ImageClassifierHelper(context) }
    
    var capturedImageUri by remember { mutableStateOf<Uri?>(null) }
    var classificationResult by remember { mutableStateOf<RecyclingInfo?>(null) }

    DisposableEffect(Unit) {
        onDispose {
            classifier.close()
        }
    }

    val cameraLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.TakePicturePreview()
    ) { bitmap ->
        if (bitmap != null) {
            try {
                val results = classifier.classify(bitmap)
                
                // Registro de diagnóstico para todos los resultados
                results.forEach { 
                    Log.d("ReciclaAI", "Clase: ${it.label}, Confianza: ${it.score}")
                }

                if (results.isNotEmpty() && results[0].score >= 0.70f) {
                    val topResult = results[0]
                    val label = topResult.label.lowercase().trim()
                    
                    Log.d("ReciclaAI", "Ganador: $label con ${topResult.score}")

                    if (label == "no basura") {
                        navController.navigate("error")
                    } else {
                        val info = getRecyclingInfo(label, null)
                        if (info.objectName == "Desconocido") {
                            Log.w("ReciclaAI", "Etiqueta '$label' detectada pero no tiene mapeo válido")
                            navController.navigate("error")
                        } else {
                            // Guardado en caché interna en lugar de la galería pública
                            val uri = saveBitmapToCache(context, bitmap)
                            
                            if (uri != null) {
                                capturedImageUri = uri
                                classificationResult = info.copy(capturedImageUri = capturedImageUri)
                                navController.navigate("result")
                            } else {
                                Log.e("ReciclaAI", "Fallo al guardar imagen en caché. Abortando navegación a resultados.")
                                navController.navigate("error")
                            }
                        }
                    }
                } else {
                    val topScore = if (results.isNotEmpty()) results[0].score else 0f
                    Log.i("ReciclaAI", "Confianza insuficiente ($topScore). Redirigiendo a error.")
                    navController.navigate("error")
                }
            } catch (e: Exception) {
                Log.e("ReciclaAI", "Excepción no controlada en el flujo de cámara: ${e.message}", e)
                navController.navigate("error")
            }
        } else {
            Log.w("ReciclaAI", "El launcher de cámara devolvió un bitmap nulo")
        }
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            cameraLauncher.launch(null)
        } else {
            Toast.makeText(context, "Permiso de cÃ¡mara denegado", Toast.LENGTH_SHORT).show()
        }
    }

    NavHost(navController = navController, startDestination = "main") {
        composable("main") {
            MainScreen(
                onScanClick = {
                    val permissionCheckResult = ContextCompat.checkSelfPermission(
                        context, 
                        Manifest.permission.CAMERA
                    )
                    if (permissionCheckResult == PackageManager.PERMISSION_GRANTED) {
                        cameraLauncher.launch(null)
                    } else {
                        permissionLauncher.launch(Manifest.permission.CAMERA)
                    }
                },
                onInfoClick = {
                    navController.navigate("info")
                },
                onHowToUseClick = {
                    navController.navigate("how_to_use")
                },
                onDevelopersClick = {
                    navController.navigate("developers")
                }
            )
        }
        composable("result") {
            classificationResult?.let { info ->
                ResultScreen(
                    info = info,
                    onBack = { navController.popBackStack() },
                    onRetry = {
                        navController.popBackStack()
                        val permissionCheckResult = ContextCompat.checkSelfPermission(
                            context, 
                            Manifest.permission.CAMERA
                        )
                        if (permissionCheckResult == PackageManager.PERMISSION_GRANTED) {
                            cameraLauncher.launch(null)
                        } else {
                            permissionLauncher.launch(Manifest.permission.CAMERA)
                        }
                    }
                )
            }
        }
        composable("error") {
            ErrorScreen(
                onBack = { 
                    navController.navigate("main") {
                        popUpTo("main") { inclusive = true }
                    }
                },
                onTryAgain = {
                    navController.popBackStack()
                    val permissionCheckResult = ContextCompat.checkSelfPermission(
                        context, 
                        Manifest.permission.CAMERA
                    )
                    if (permissionCheckResult == PackageManager.PERMISSION_GRANTED) {
                        cameraLauncher.launch(null)
                    } else {
                        permissionLauncher.launch(Manifest.permission.CAMERA)
                    }
                }
            )
        }
        composable("info") {
            InfoScreen(onBack = { navController.popBackStack() })
        }
        composable("developers") {
            DevelopersScreen(onBack = { navController.popBackStack() })
        }
        composable("how_to_use") {
            HowToUseScreen(onBack = { navController.popBackStack() })
        }
    }
}

/**
 * Guarda un Bitmap en el directorio de caché interno de la aplicación.
 * Esto evita que las imágenes aparezcan en la galería del usuario.
 */
private fun saveBitmapToCache(context: Context, bitmap: Bitmap): Uri? {
    return try {
        val imagesFolder = File(context.cacheDir, "images")
        if (!imagesFolder.exists()) {
            imagesFolder.mkdirs()
        }
        val file = File(imagesFolder, "captured_image_${System.currentTimeMillis()}.jpg")
        val stream = FileOutputStream(file)
        bitmap.compress(Bitmap.CompressFormat.JPEG, 90, stream)
        stream.flush()
        stream.close()
        Uri.fromFile(file)
    } catch (e: Exception) {
        Log.e("ReciclaAI", "Error al guardar imagen en caché: ${e.message}")
        null
    }
}

fun getRecyclingInfo(label: String, uri: Uri?): RecyclingInfo {
    // Normalizar: quitar acentos y pasar a minúsculas para mayor robustez
    val l = label.lowercase()
        .replace("á", "a")
        .replace("é", "e")
        .replace("í", "i")
        .replace("ó", "o")
        .replace("ú", "u")

    return when {
        l.contains("plastico") -> RecyclingInfo(
            objectName = "Plástico",
            residueType = "Envases de plástico, latas y envases tipo brik",
            containerName = "Contenedor AMARILLO",
            containerColor = Color(0xFFFFEB3B),
            instructions = "Enjuaga los envases si tienen restos. Aplástalos para ahorrar espacio. Incluye botellas, tarrinas y bolsas.",
            capturedImageUri = uri
        )
        l.contains("papel") -> RecyclingInfo(
            objectName = "Papel",
            residueType = "Papeles y hojas",
            containerName = "Contenedor AZUL",
            containerColor = Color(0xFF2196F3),
            instructions = "Asegúrate de que el papel no tenga manchas de grasa o comida. Quita grapas si es posible.",
            capturedImageUri = uri
        )
        l.contains("carton") -> RecyclingInfo(
            objectName = "Cartón",
            residueType = "Cajas y envases de cartón",
            containerName = "Contenedor AZUL",
            containerColor = Color(0xFF2196F3),
            instructions = "Pliega las cajas de cartón para que ocupen menos espacio. Retira restos de precinto plástico.",
            capturedImageUri = uri
        )
        l.contains("vidrio") -> RecyclingInfo(
            objectName = "Vidrio",
            residueType = "Botellas, frascos y tarros de vidrio",
            containerName = "Contenedor VERDE",
            containerColor = Color(0xFF4CAF50),
            instructions = "Quita los tapones y las tapas. Solo envases de vidrio, no deposites cristal (espejos, vasos, bombillas).",
            capturedImageUri = uri
        )
        l.contains("metal") -> RecyclingInfo(
            objectName = "Metal",
            residueType = "Envases metálicos, latas y aluminio",
            containerName = "Contenedor AMARILLO",
            containerColor = Color(0xFFFFEB3B),
            instructions = "Limpia los envases para eliminar restos de comida o bebida antes de reciclarlos.",
            capturedImageUri = uri
        )
        l.contains("organico") -> RecyclingInfo(
            objectName = "Orgánico",
            residueType = "Restos de comida y materia biodegradable",
            containerName = "Contenedor MARRÓN",
            containerColor = Color(0xFF795548),
            instructions = "Deposita los residuos orgánicos en bolsas biodegradables cuando sea posible",
            capturedImageUri = uri
        )
        else -> RecyclingInfo(
            objectName = "Desconocido",
            residueType = "N/A",
            containerName = "N/A",
            containerColor = Color.Gray,
            instructions = "N/A",
            capturedImageUri = uri
        )
    }
}
