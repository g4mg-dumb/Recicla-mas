﻿package com.example.recicla

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.MenuBook
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch

val AppBackground = Color(0xFFF9F9EF)
val DarkGreen = Color(0xFF1B4332)
val LightGreen = Color(0xFF74A15E)

/**
 * Pantalla principal de la aplicación de reciclaje.
 */
@Composable
fun MainScreen(
    onScanClick: () -> Unit,
    onInfoClick: () -> Unit = {},
    onHowToUseClick: () -> Unit = {},
    onDevelopersClick: () -> Unit = {}
) {
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val scope = rememberCoroutineScope()

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet(
                drawerContainerColor = AppBackground,
                drawerShape = RoundedCornerShape(topEnd = 16.dp, bottomEnd = 16.dp)
            ) {
                Spacer(modifier = Modifier.height(24.dp))
                
                // Encabezado del Drawer con Logo
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.app_logo),
                        contentDescription = null,
                        modifier = Modifier
                            .size(80.dp)
                            .clip(CircleShape)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "RECICLA+",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        color = DarkGreen
                    )
                }

                HorizontalDivider(modifier = Modifier.padding(horizontal = 16.dp))
                
                Spacer(modifier = Modifier.height(16.dp))

                // Items del Menú
                NavigationDrawerItem(
                    label = { Text("Inicio", fontWeight = FontWeight.SemiBold) },
                    selected = false,
                    onClick = { scope.launch { drawerState.close() } },
                    icon = { Icon(Icons.Default.Home, contentDescription = null) },
                    modifier = Modifier.padding(NavigationDrawerItemDefaults.ItemPadding),
                    colors = NavigationDrawerItemDefaults.colors(
                        unselectedTextColor = DarkGreen,
                        unselectedIconColor = DarkGreen
                    )
                )

                NavigationDrawerItem(
                    label = { Text("Desarrolladores", fontWeight = FontWeight.SemiBold) },
                    selected = false,
                    onClick = { 
                        scope.launch { 
                            drawerState.close()
                            onDevelopersClick()
                        } 
                    },
                    icon = { Icon(Icons.Default.Groups, contentDescription = null) },
                    modifier = Modifier.padding(NavigationDrawerItemDefaults.ItemPadding),
                    colors = NavigationDrawerItemDefaults.colors(
                        unselectedTextColor = DarkGreen,
                        unselectedIconColor = DarkGreen
                    )
                )
            }
        }
    ) {
        Scaffold(
            modifier = Modifier.fillMaxSize(),
            containerColor = AppBackground,
            topBar = {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 40.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    IconButton(onClick = { scope.launch { drawerState.open() } }) {
                        Icon(
                            imageVector = Icons.Default.Menu,
                            contentDescription = "Menu",
                            tint = DarkGreen,
                            modifier = Modifier.size(32.dp)
                        )
                    }
                }
            }
        ) { innerPadding ->
            Box(modifier = Modifier.fillMaxSize().padding(innerPadding)) {
                // Background Leaf Decorations
                Icon(
                    imageVector = Icons.Default.Eco,
                    contentDescription = null,
                    tint = LightGreen.copy(alpha = 0.2f),
                    modifier = Modifier
                        .size(120.dp)
                        .align(Alignment.CenterStart)
                        .offset(x = (-40).dp, y = (-150).dp)
                )
                Icon(
                    imageVector = Icons.Default.Spa,
                    contentDescription = null,
                    tint = LightGreen.copy(alpha = 0.2f),
                    modifier = Modifier
                        .size(150.dp)
                        .align(Alignment.BottomStart)
                        .offset(x = (-50).dp, y = (-250).dp)
                )

                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Spacer(modifier = Modifier.height(20.dp))

                    // Logo and Title Section
                    Image(
                        painter = painterResource(id = R.drawable.app_logo),
                        contentDescription = "Logo Recicla+",
                        modifier = Modifier
                            .size(120.dp)
                            .clip(CircleShape)
                    )
                    Text(
                        text = "RECICLA+",
                        fontSize = 32.sp,
                        fontWeight = FontWeight.Bold,
                        color = DarkGreen,
                        modifier = Modifier.padding(top = 8.dp)
                    )
                    Text(
                        text = "Escanea. Aprende. Recicla.\nCuida nuestro planeta 💚",
                        textAlign = TextAlign.Center,
                        fontSize = 16.sp,
                        color = DarkGreen,
                        lineHeight = 22.sp,
                        modifier = Modifier.padding(top = 8.dp)
                    )

                    Spacer(modifier = Modifier.height(40.dp))

                    // Action Buttons
                    ActionButton(
                        title = "ESCANEAR OBJETO",
                        subtitle = "Toma una foto y descubre cómo reciclarlo",
                        icon = Icons.Default.CameraAlt,
                        backgroundColor = DarkGreen,
                        onClick = onScanClick
                    )

                    Spacer(modifier = Modifier.height(20.dp))

                    ActionButton(
                        title = "INFORMACIÓN",
                        subtitle = "Aprende sobre reciclaje y puntos cercanos",
                        icon = Icons.AutoMirrored.Filled.MenuBook,
                        backgroundColor = LightGreen,
                        onClick = onInfoClick
                    )

                    Spacer(modifier = Modifier.height(20.dp))

                    ActionButton(
                        title = "¿CÓMO SE USA?",
                        subtitle = "Consejos para un escaneo perfecto",
                        icon = Icons.Default.Info,
                        backgroundColor = DarkGreen,
                        onClick = onHowToUseClick
                    )

                    Spacer(modifier = Modifier.weight(1f))

                    // Footer Section
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(140.dp),
                        shape = RoundedCornerShape(24.dp),
                        colors = CardDefaults.cardColors(containerColor = Color.White)
                    ) {
                        Column(
                            modifier = Modifier.fillMaxSize(),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            Text(
                                text = "Juntos hacemos la diferencia",
                                fontWeight = FontWeight.Bold,
                                color = DarkGreen,
                                modifier = Modifier.padding(bottom = 8.dp)
                            )
                            Icon(
                                imageVector = Icons.Default.Public,
                                contentDescription = null,
                                tint = LightGreen,
                                modifier = Modifier.size(60.dp)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(32.dp))
                }
            }
        }
    }
}

@Composable
fun ActionButton(
    title: String,
    subtitle: String,
    icon: ImageVector,
    backgroundColor: Color,
    onClick: () -> Unit
) {
    Button(
        onClick = onClick,
        modifier = Modifier
            .fillMaxWidth()
            .height(100.dp),
        shape = RoundedCornerShape(24.dp),
        colors = ButtonDefaults.buttonColors(containerColor = backgroundColor),
        contentPadding = PaddingValues(horizontal = 24.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(
                modifier = Modifier.size(56.dp),
                shape = CircleShape,
                color = Color.White
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = backgroundColor,
                        modifier = Modifier.size(28.dp)
                    )
                }
            }
            Spacer(modifier = Modifier.width(16.dp))
            Column {
                Text(
                    text = title,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
                Text(
                    text = subtitle,
                    fontSize = 14.sp,
                    color = Color.White.copy(alpha = 0.8f),
                    lineHeight = 18.sp
                )
            }
        }
    }
}

@Preview(showBackground = true)
@Composable
fun MainScreenPreview() {
    MainScreen(onScanClick = {})
}
